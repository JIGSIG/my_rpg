/*
** EPITECH PROJECT, 2018
** rpg
** File description:
** include function
*/

#include "rpg.h"

t_villager *create_node_villager(char *name)
{
    t_RECT rect = {0, 0, 32, 48};
    t_villager *new = malloc(sizeof(*new));
    static sfVector2f position = {1450, 2750};
    static int number = 0;

    if (new == NULL)
        return (NULL);
    new->character = name;
    new->sprite = sfSprite_create();
    new->texture = sfTexture_createFromFile(name, NULL);
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    new->clock = sfClock_create();
    new->position = position;
    set_rect(&new->rect, rect);
    new->next = NULL;
    new->prev = NULL;
    new->number = number;
    position = (sfVector2f){position.x + 100, position.y - 100};
    number += 1;
    return (new);
}

t_villager *dlist_append_villager(t_villager *list, char *name)
{
    t_villager *new;
    t_villager *tmp;

    if (list == NULL)
        return (NULL);
    tmp = list;
    new = create_node_villager(name);
    while (list->next != NULL)
        list = list->next;
    list->next = new;
    new->prev = list;
    list = tmp;
    return (list);
}
