/*
** EPITECH PROJECT, 2018
** rpg
** File description:
** include function
*/

#include "rpg.h"

char **get_name(int nb_of_character, char *ID)
{
    char **name = NULL;
    int i;
    int end = nb_of_character;

    name = malloc(sizeof(char *) * (end + 1));
    if (!name)
        return (NULL);
    for (i = 0; i < (end + 1); i++) {
        name[i] = NULL;
        name[i] = malloc(sizeof(char) * (8 + 1));
        if (!name[i])
            return (NULL);
        name[i] = my_strcat("assets/", ID);
        name[i] = my_strcat(name[i], my_itoa(i, 10));
        name[i] = my_strcat(name[i], ".png");
    } name[end] = NULL;
    return (name);
}

t_pj *create_node(char *name)
{
    t_pj *new;

    new = malloc(sizeof(*new));
    if (new == NULL)
        return (NULL);
    new->character = name;
    new->sprite = sfSprite_create();
    new->texture = sfTexture_createFromFile(name, NULL);
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    new->next = NULL;
    new->prev = NULL;
    return (new);
}

t_pj *dlist_append(t_pj *list, char *name)
{
    t_pj *new;
    t_pj *tmp;

    if (list == NULL)
        return (NULL);
    tmp = list;
    new = create_node(name);
    while (list->next != NULL)
        list = list->next;
    list->next = new;
    new->prev = list;
    list = tmp;
    return (list);
}
