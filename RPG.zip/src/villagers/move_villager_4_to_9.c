/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void move_villager_5(t_villager *villager)
{
    static sfVector2f position = {1408, 523};
    static bool turn = true;

    if (turn == true) {
        position.y -= 0.05;
        villager->position = position;
        anim_villager(UP, 32, 64, villager);
        if (position.y >= 1400 && position.y <= 1409)
            turn = false;
    } if (turn == false) {
        position.y += 0.05;
        villager->position = position;
        anim_villager(DOWN, 32, 64, villager);
        if (position.y >= 2720  && position.y <= 2750)
            turn = true;
    }
}

void move_villager_6(t_villager *villager)
{
    static sfVector2f position = {614, 2404};
    static bool turn = true;

    if (turn == true) {
        position.y -= 0.05;
        villager->position = position;
        anim_villager(LEFT, 32, 64, villager);
        if (position.x >= 600 && position.x <= 2032)
            turn = false;
    } if (turn == false) {
        position.y += 0.05;
        villager->position = position;
        anim_villager(RIGHT, 32, 64, villager);
        if (position.x >= 600  && position.x <= 2750)
            turn = true;
    }
}

void move_villager_7(t_villager *villager)
{
    static sfVector2f position = {449, 2370};
    static bool turn = true;

    if (turn == true) {
        position.y -= 0.05;
        villager->position = position;
        anim_villager(UP, 32, 64, villager);
        if (position.y >= 2000 && position.y <= 2032)
            turn = false;
    } if (turn == false) {
        position.y += 0.05;
        villager->position = position;
        anim_villager(DOWN, 32, 64, villager);
        if (position.y >= 2720  && position.y <= 2750)
            turn = true;
    }
}

void move_villager_8(t_villager *villager)
{
    static sfVector2f position = {1228, 1441};
    static bool turn = true;

    if (turn == true) {
        position.x -= 0.05;
        villager->position = position;
        anim_villager(RIGHT, 32, 64, villager);
        if (position.y >= 2000 && position.y <= 2032)
            turn = false;
    } if (turn == false) {
        position.x += 0.05;
        villager->position = position;
        anim_villager(LEFT, 32, 64, villager);
        if (position.x >= 2720  && position.x <= 2750)
            turn = true;
    }
}

void move_villager_9(t_villager *villager)
{
    static sfVector2f position = {1450, 2750};
    static bool turn = true;

    if (turn == true) {
        position.y -= 0.05;
        villager->position = position;
        anim_villager(UP, 32, 64, villager);
        if (position.y >= 2000 && position.y <= 2032)
            turn = false;
    } if (turn == false) {
        position.y += 0.05;
        villager->position = position;
        anim_villager(DOWN, 32, 64, villager);
        if (position.y >= 2720  && position.y <= 2750)
            turn = true;
    }
}
