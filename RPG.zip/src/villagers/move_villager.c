/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void anim_villager(int top, int offset, int max_value, t_villager *villager)
{
    villager->time = sfClock_getElapsedTime(villager->clock);
    villager->seconds = villager->time.microseconds / 100000;
    if (villager->seconds > 1.0) {
        villager->rect.top = top;
        villager->rect.left += offset;
        if (villager->rect.left == max_value) {
            villager->rect.left = 0;
        } sfClock_restart(villager->clock);
    }

}

static void move_villager_0_to_5(t_villager *villager)
{
    switch (villager->number) {
    case 0:
        move_villager_0(villager);
        break;
    case 1:
        move_villager_1(villager);
        break;
    case 2:
        move_villager_2(villager);
        break;
    case 3:
        move_villager_3(villager);
        break;
    case 4:
        move_villager_4(villager);
        break;
    case 5:
        move_villager_5(villager);
        break;
    }
}

static void move_villager_6_to_11(t_villager *villager)
{
    switch (villager->number) {
    case 6:
        move_villager_6(villager);
        break;
    case 7:
        move_villager_7(villager);
        break;
    case 8:
        move_villager_8(villager);
        break;
    case 9:
        move_villager_9(villager);
        break;
    case 10:
        move_villager_10(villager);
        break;
    case 11:
        move_villager_11(villager);
        break;
    }
}

void move_villager(t_villager *villager)
{
    move_villager_0_to_5(villager);
    move_villager_6_to_11(villager);
}
