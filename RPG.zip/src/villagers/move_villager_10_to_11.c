/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void move_villager_10(t_villager *villager)
{
    static sfVector2f position = {70, 2750};
    static bool turn = true;

    if (turn == true) {
        position.y -= 0.05;
        villager->position = position;
        anim_villager(UP, 32, 64, villager);
        if (position.y >= 2000 && position.y <= 2032)
            turn = false;
    } if (turn == false) {
        position.y += 0.05;
        villager->position = position;
        anim_villager(DOWN, 32, 64, villager);
        if (position.y >= 2720  && position.y <= 2750)
            turn = true;
    }
}

void move_villager_11(t_villager *villager)
{
    static sfVector2f position = {50, 2750};
    static bool turn = true;

    if (turn == true) {
        position.y -= 0.05;
        villager->position = position;
        anim_villager(UP, 32, 64, villager);
        if (position.y >= 2000 && position.y <= 2032)
            turn = false;
    } if (turn == false) {
        position.y += 0.05;
        villager->position = position;
        anim_villager(DOWN, 32, 64, villager);
        if (position.y >= 2720  && position.y <= 2750)
            turn = true;
    }
}
