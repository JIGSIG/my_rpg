/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void check_event_intro(sfMouseButtonEvent event, t_game *game)
{
    static bool enter = false;

    if (game->status_OG != INTRO)
        return;
    if (sfKeyboard_isKeyPressed(sfKeyReturn)
        || (((event.x > 1770 && event.x < 1920)
        && (event.y > 880 && event.y < 1080))))
        enter = true;
    if (enter == true) {
        game->intro.rect.left = 0;
        enter = false;
    }
}
