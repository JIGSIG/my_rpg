/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void check_event_confirm(sfMouseButtonEvent event, t_game *game)
{
    if (game->render.event.type == sfEvtMouseButtonPressed
        && game->status_IG == CONFIRM) {
        if ((event.x > 545 && event.x < 940)
            && (event.y > 510 && event.y < 625))
            game->status_OG = EXIT;
        if ((event.x > 975 && event.x < 1375)
            && (event.y > 510 && event.y < 630))
            game->status_IG = OPTION;
    }
}

void check_event_config(t_game *game)
{
    if (game->status_IG == CONFIGURATION
        && game->status_OG == MENU) {
        if (sfKeyboard_isKeyPressed(sfKeyQ))
            game->status_IG = RESUME;
    } if (game->status_IG == CONFIGURATION) {
        if (sfKeyboard_isKeyPressed(sfKeyLeft))
            volume_down(game);
        if (sfKeyboard_isKeyPressed(sfKeyRight))
            volume_up(game);
        if (sfKeyboard_isKeyPressed(sfKeyDown))
            mute_volume();
        if (sfKeyboard_isKeyPressed(sfKeyUp))
            active_volume(game);
    }
}

void check_event_option(sfMouseButtonEvent event, t_game *game)
{
    if (game->render.event.type == sfEvtMouseButtonPressed
        && game->status_IG == OPTION) {
        if ((event.x > 45 && event.x < 125)
            && (event.y > 40 && event.y < 75))
            game->status_IG = ITEM;
        if ((event.x > 45 && event.x < 185)
            && (event.y > 315 && event.y < 345))
            game->status_IG = CONFIGURATION;
        if ((event.x > 45 && event.x < 900)
            && (event.y > 360 && event.y < 390))
            game->status_IG = SAVE;
        if ((event.x > 45 && event.x < 240)
            && (event.y > 415 && event.y < 455))
            game->status_IG = CONFIRM;
    } if (sfKeyboard_isKeyPressed(sfKeyReturn)) {
        game->status_IG = MAP;
        if (game->old_status_IG == HOUSE)
            game->status_IG = HOUSE;
    }
}
