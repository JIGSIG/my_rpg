/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

static void go_right(sfMouseButtonEvent event, t_game *game)
{
    static bool right = false;

    if (sfKeyboard_isKeyPressed(sfKeyRight)
        || (((event.x > 1270 && event.x < 1335)
        && (event.y > 440 && event.y < 575))))
        right = true;
    if (right == true) {
        if (game->player.pj->next)
            game->player.pj = game->player.pj->next;
        right = false;
    }
}

static void go_left(sfMouseButtonEvent event, t_game *game)
{
    static bool left = false;

    if (sfKeyboard_isKeyPressed(sfKeyLeft)
        || (((event.x > 570 && event.x < 755)
        && (event.y > 440 && event.y < 575))))
        left = true;
    if (left == true) {
        if (game->player.pj->prev)
            game->player.pj = game->player.pj->prev;
        left = false;
    }
}

void check_event_selection(sfMouseButtonEvent event, t_game *game)
{
    static bool enter = false;

    go_right(event, game);
    go_left(event, game);
    if (sfKeyboard_isKeyPressed(sfKeySpace)
        || (((event.x > 660 && event.x < 1050)
        && (event.y > 515 && event.y < 665))))
        enter = true;
    if (enter == true) {
        game->status_OG = INTRO;
        game->status_IG = MAP;
        enter = false;
    }
}
