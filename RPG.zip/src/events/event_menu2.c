/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

static void start_button(t_game *game)
{
    game->menu.Prectangle.x = 945;
    game->menu.Prectangle.y = 842;
    sfRectangleShape_setSize
        (game->menu.rectangle, (sfVector2f){130, 30});
}

static void config_button(t_game *game)
{
    game->menu.Prectangle.x = 925;
    game->menu.Prectangle.y = 900;
    sfRectangleShape_setSize
        (game->menu.rectangle, (sfVector2f){170, 30});
}

static void quit_button(t_game *game)
{
    game->menu.Prectangle.x = 980;
    game->menu.Prectangle.y = 955;
    sfRectangleShape_setSize
        (game->menu.rectangle, (sfVector2f){60, 30});
}

void move_rectangle_up(t_game *game)
{
    switch ((int)game->menu.Prectangle.y) {
    case 842:
        quit_button(game);
        break;
    case 900:
        start_button(game);
        break;
    case 955:
        config_button(game);
        break;
    }
}

void move_rectangle_down(t_game *game)
{
    switch ((int)game->menu.Prectangle.y) {
    case 842:
        config_button(game);
        break;
    case 900:
        quit_button(game);
        break;
    case 955:
        start_button(game);
        break;
    }
}
