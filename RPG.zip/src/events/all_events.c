/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void analyse_event(t_game *game, t_render *render)
{
    while (sfRenderWindow_pollEvent(render->window, &render->event)) {
        if (render->event.type == sfEvtClosed) {
            game->status_OG = EXIT;
        } if (game->status_IG == OPTION)
            check_event_option(game->render.event.mouseButton, game);
        if (game->status_OG == MENU)
            check_event_menu(game->render.event.mouseButton, game);
        if (game->status_OG == GAME)
            check_event_game(game->render.event.mouseButton, game);
        if (game->status_OG == SELECTION)
            check_event_selection(game->render.event.mouseButton, game);
        if (game->status_OG == INTRO)
            check_event_intro(game->render.event.mouseButton, game);
        if (game->status_IG == CONFIRM)
            check_event_confirm(game->render.event.mouseButton, game);
        if (game->status_IG == CONFIGURATION)
            check_event_config(game);
    }
}
