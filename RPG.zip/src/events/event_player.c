/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

int move_down(t_player *player, int *old, int status_IG)
{
    int direction;

    direction = *old;
    if (sfKeyboard_isKeyPressed(sfKeyDown)) {
        player->position.y += 0.15;
        if (status_IG == MAP && check_player_move(player) == false) {
            player->position.y -= 0.15;
            return (direction);
        } player->position.y += 0.15;
        if (status_IG == MAP && player->position.y >= 3040)
            player->position.y -= 0.15;
        if (status_IG == HOUSE && player->position.y >= 1015)
            player->position.y -= 0.15;
        direction = DOWN;
        anim_player(direction, 32, 64, player);
    } return (direction);
}

int move_left(t_player *player, int *old, int status_IG)
{
    int direction;

    direction = *old;
    if (sfKeyboard_isKeyPressed(sfKeyRight)) {
        player->position.x += 0.15;
        if (status_IG == MAP && check_player_move(player) == false) {
            player->position.x -= 0.15;
            return (direction);
        } player->position.x += 0.15;
        if (status_IG == MAP && player->position.x >= 1856)
            player->position.x -= 0.15;
        if (status_IG == HOUSE && player->position.x >= 1920)
            player->position.x -= 0.15;
        direction = LEFT;
        anim_player(direction, 32, 64, player);
    } return (direction);
}

int move_right(t_player *player, int *old, int status_IG)
{
    int direction;

    direction = *old;
    if (sfKeyboard_isKeyPressed(sfKeyLeft)) {
        player->position.x -= 0.15;
        if (status_IG == MAP && check_player_move(player) == false) {
            player->position.x += 0.15;
            return (direction);
        } player->position.x -= 0.15;
        if (status_IG == MAP && player->position.x <= 32)
            player->position.x += 0.15;
        if (status_IG == HOUSE && player->position.x <= 32)
            player->position.x += 0.15;
        direction = RIGHT;
        anim_player(direction, 32, 64, player);
    } return (direction);
}

int move_up(t_player *player, int *old, int status_IG)
{
    int direction;

    direction = *old;
    if (sfKeyboard_isKeyPressed(sfKeyUp)) {
        player->position.y -= 0.15;
        if (status_IG == MAP && check_player_move(player) == false) {
            player->position.y += 0.15;
            return (direction);
        } player->position.y -= 0.15;
        if (status_IG == MAP && player->position.y <= 32)
            player->position.y += 0.15;
        if (status_IG == HOUSE && player->position.y <= 32)
            player->position.y += 0.15;
        direction = UP;
        anim_player(direction, 32, 64, player);
    } return (direction);
}
