/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

static void event_start(sfMouseButtonEvent event, t_game *game)
{
    if ((event.x > 945 && event.x < 1075)
        && (event.y > 840 && event.y < 870)) {
            game->status_OG = SELECTION;
            game->status_IG = RESUME;
    }
}

static void event_configuration(sfMouseButtonEvent event, t_game *game)
{
    if ((event.x > 900 && event.x < 1015)
        && (event.y > 900 && event.y < 930)) {
        game->status_OG = MENU;
        game->status_IG = CONFIGURATION;
    }
}

static void event_quit(sfMouseButtonEvent event, t_game *game)
{
    if ((event.x > 980 && event.x < 1045)
        && (event.y > 955 && event.y < 985)) {
        game->status_OG = EXIT;
    }
}

static void select_button(t_game *game)
{
    if (sfKeyboard_isKeyPressed(sfKeyReturn)) {
        switch ((int)game->menu.Prectangle.y) {
        case 842:
            game->status_OG = SELECTION;
            game->status_IG = RESUME;
            break;
        case 900:
            game->status_OG = MENU;
            game->status_IG = CONFIGURATION;
            break;
        case 955:
            game->status_OG = EXIT;
            break;
        }
    }
}

void check_event_menu(sfMouseButtonEvent event, t_game *game)
{
    if (sfKeyboard_isKeyPressed(sfKeyUp))
        move_rectangle_up(game);
    if (sfKeyboard_isKeyPressed(sfKeyDown))
        move_rectangle_down(game);
    if (sfKeyboard_isKeyPressed(sfKeyEscape))
        game->status_OG = EXIT;
    if (game->render.event.type == sfEvtMouseButtonPressed
        && game->status_OG == MENU) {
        event_start(event, game);
        event_configuration(event, game);
        event_quit(event, game);
    } select_button(game);
}
