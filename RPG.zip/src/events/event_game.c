/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void check_event_game(sfMouseButtonEvent event, t_game *game)
{
    if (sfKeyboard_isKeyPressed(sfKeyEscape))
        game->status_IG = OPTION;
    if (sfKeyboard_isKeyPressed(sfKeyI))
        game->status_IG = ITEM;
    if (game->render.event.type == sfEvtMouseButtonPressed
        && game->status_IG == MAP) {
        if ((event.x > 15 && event.x < 125)
            && (event.y > 25 && event.y < 80))
            game->status_IG = OPTION;
    }
}
