/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void start_game_music(t_game *game)
{
    static bool play = false;

    if (play == false) {
        sfMusic_stop(game->menu.music);
        sfMusic_setLoop(game->map.music, true);
        sfMusic_play(game->map.music);
        play = true;
    }
}

void start_selection_music(t_game *game)
{
    static bool play = false;

    if (play == false) {
        sfMusic_stop(game->menu.music);
        sfMusic_setLoop(game->map.music, true);
        sfMusic_play(game->map.music);
        play = true;
    }
}

void start_menu_music(t_game *game)
{
    static bool play = false;

    if (play == false) {
        sfMusic_setLoop(game->menu.music, true);
        sfMusic_play(game->menu.music);
        play = true;
    }
}
