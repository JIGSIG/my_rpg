/*
** EPITECH PROJECT, 2019
** my_rpg
** File description:
** Principal function
*/

#include "rpg.h"

int main(int ac, char **av)
{
    if (ac == 1
        || (ac == 2 && av[1][0] == '-' && av[1][1] == 'h'))
        rpg_game();
    else
        return (84);
    return (0);
}
