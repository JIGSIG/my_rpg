/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_status_bar(t_status_bar *new)
{
    new->sprite = sfSprite_create();
    new->texture = sfTexture_createFromFile("assets/player_status2.png", NULL);
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
}
