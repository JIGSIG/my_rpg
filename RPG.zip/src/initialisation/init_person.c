/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_person(t_person *new)
{
    t_RECT rect;

    rect.width = 32;
    rect.heigth = 32;
    new->sprite1 = sfSprite_create();
    new->texture1 = sfTexture_createFromFile("assets/pj_2.png", NULL);
    new->position1.x = 1406;
    new->position1.y = 2612;
    sfSprite_setTexture(new->sprite1, new->texture1, sfTrue);
    new->clock1 = sfClock_create();
    set_rect(&new->rect1, rect);
    new->next1 = NULL;
}

void init_person2(t_person *new)
{
    t_RECT rect;

    rect.width = 32;
    rect.heigth = 32;
    new->sprite2 = sfSprite_create();
    new->texture2 = sfTexture_createFromFile("assets/galler17.png", NULL);
    new->position2.x = 612;
    new->position2.y = 2326;
    sfSprite_setTexture(new->sprite2, new->texture2, sfTrue);
    new->clock2 = sfClock_create();
    set_rect(&new->rect2, rect);
    new->next2 = NULL;
}
