/*
** EPITECH PROJECT, 2019
** my_rpg
** File description:
** rpg
*/

#include "rpg.h"

void init_map(t_map *new)
{
    new->texture = sfTexture_createFromFile("assets/map.jpg", NULL);
    new->sprite = sfSprite_create();
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    new->music = sfMusic_createFromFile("sound/first_layer.ogg");
}

void init_house(t_house *new)
{
    new->texture = sfTexture_createFromFile("assets/house.jpg", NULL);
    new->sprite = sfSprite_create();
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
}
