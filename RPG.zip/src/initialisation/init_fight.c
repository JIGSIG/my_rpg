/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_fight(t_fight *new)
{
    t_RECT coord = {0, 0, 235, 320};

    new->texture = sfTexture_createFromFile("assets/shifumi.png", NULL);
    new->sprite = sfSprite_create();
    new->clock = sfClock_create();
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    set_rect(&new->rect, coord);
    new->rectangle = sfRectangleShape_create();
    new->Prectangle.x = (1920 / 2) - ((723 * 0.65) / 2) + 25;
    new->Prectangle.y = 1080 - (420 * 0.65);
    sfRectangleShape_setSize
        (new->rectangle, (sfVector2f){235 * 0.65, 320 * 0.65});
    new->music = sfMusic_createFromFile("sound/opening.ogg");
}

void fight_anim(t_fight *fight, int offset, int max_value)
{
    fight->time = sfClock_getElapsedTime(fight->clock);
    fight->seconds = fight->time.microseconds / 100000;
    if (fight->seconds > 1.0) {
        fight->rect.left += offset;
        if (fight->rect.left == max_value) {
            fight->rect.left = 0;
        } sfClock_restart(fight->clock);
    }
}
