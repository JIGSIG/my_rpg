/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

static void init_part1(t_game *new)
{
    init_render(&new->render);
    init_menu(&new->menu);
    init_selection(&new->selection);
    init_map(&new->map);
    init_house(&new->house);
    init_option(&new->option);
    init_finger(&new->finger);
    init_inventory(&new->inventory);
    init_quit(&new->quit);
    init_configuration(&new->config);
    init_text(&new->font);
    init_tchat(&new->tchat);
    init_treasure(&new->treasure);
    init_status_bar(&new->status_bar);
}

static void init_part2(t_game *new)
{
    init_player(&new->player);
    init_villager(&new->villager);
    init_level(&new->level);
    init_person(&new->person);
    init_person2(&new->person);
    init_blur(&new->blur);
    init_rain(&new->rain);
    init_intro(&new->intro);
    init_fight(&new->fight);
    new->status_OG = MENU;
    new->status_IG = RESUME;
    new->volume = 100;
    if (!new->player.map)
        new->status_OG = EXIT;

}

void init_game(t_game *new)
{
    init_part1(new);
    init_part2(new);
}
