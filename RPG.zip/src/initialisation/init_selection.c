/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_selection(t_selection *new)
{
    t_RECT rect = {0, 0, 64, 64};

    new->sprite2 = sfSprite_create();
    new->texture2 = sfTexture_createFromFile("assets/select_back.jpg", NULL);
    sfSprite_setTexture(new->sprite2, new->texture2, sfTrue);
    new->sprite = sfSprite_create();
    new->texture = sfTexture_createFromFile("assets/ring.png", NULL);
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    new->clock = sfClock_create();
    set_rect(&new->rect, rect);
}

void ring_anim(t_selection *selection, int offset, int max_value)
{
    selection->time = sfClock_getElapsedTime(selection->clock);
    selection->seconds = selection->time.microseconds / 100000;
    if (selection->seconds > 1.0) {
        selection->rect.left += offset;
        if (selection->rect.left == max_value) {
            selection->rect.left = 0;
        } sfClock_restart(selection->clock);
    }
}

void select_anim(t_player *player, int offset, int max_value, int top)
{
    player->time = sfClock_getElapsedTime(player->clock);
    player->seconds = player->time.microseconds / 100000;
    player->rect.top = top;
    if (player->seconds > 1.0) {
        player->rect.left += offset;
        if (player->rect.left == max_value) {
            player->rect.left = 0;
        } sfClock_restart(player->clock);
    }
}
