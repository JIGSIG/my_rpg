/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_rain(t_rain *new)
{
    t_RECT rect;

    rect.width = 1920;
    rect.heigth = 3104;
    new->sprite = sfSprite_create();
    new->texture = sfTexture_createFromFile("assets/rain2.png", NULL);
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    new->clock = sfClock_create();
    set_rect(&new->rect, rect);
}

void anim_rain(t_rain *rain, int offset, int max_value)
{
    rain->time = sfClock_getElapsedTime(rain->clock);
    rain->seconds = rain->time.microseconds / 100000;
    if (rain->seconds > 1.0) {
        rain->rect.left += offset;
        if (rain->rect.left == max_value) {
            rain->rect.left = 0;
        } sfClock_restart(rain->clock);
    }
}
