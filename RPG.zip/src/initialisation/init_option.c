/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_option(t_option *new)
{
    new->texture = sfTexture_createFromFile("assets/option.png", NULL);
    new->sprite = sfSprite_create();
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
}

void init_finger(t_finger *new)
{
    t_RECT coord;

    coord.width = 156;
    coord.heigth = 70;
    new->texture = sfTexture_createFromFile("assets/black.png", NULL);
    new->sprite = sfSprite_create();
    new->position.x = 0;
    new->position.y = 0;
    new->clock = sfClock_create();
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    set_rect(&new->rect, coord);
}
