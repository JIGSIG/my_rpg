/*
** EPITECH PROJECT, 2018
** rpg
** File description:
** include function
*/

#include "rpg.h"

void init_level(t_level *new)
{
    t_RECT rect = {192 * 2, 0, 192, 192};

    new->sprite = sfSprite_create();
    new->texture = sfTexture_createFromFile("assets/level_animation.png", NULL);
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    new->clock = sfClock_create();
    new->position = (sfVector2f){-1450, -2750};
    set_rect(&new->rect, rect);
}

void anim_level(int offset, int max_value,
                t_level *level, bool *display)
{
    level->time = sfClock_getElapsedTime(level->clock);
    level->seconds = level->time.microseconds / 100000;
    if (level->seconds > 1.0) {
        level->rect.left += offset;
        if (level->rect.left == max_value) {
            level->rect.left = 0;
            level->rect.top += 192;
        } sfClock_restart(level->clock);
    } if (level->rect.top == 192 * 4) {
        level->rect.top = 0;
        *display = false;
    }
}
