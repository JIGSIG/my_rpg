/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_menu(t_menu *new)
{
    t_RECT rect = {0, 0, 244, 162};

    new->texture = sfTexture_createFromFile("assets/ff.png", NULL);
    new->sprite = sfSprite_create();
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    new->clock = sfClock_create();
    set_rect(&new->rect, rect);
    new->rectangle = sfRectangleShape_create();
    new->Prectangle.x = 945;
    new->Prectangle.y = 842;
    sfRectangleShape_setSize(new->rectangle, (sfVector2f){130, 30});
    new->music = sfMusic_createFromFile("sound/opening.ogg");
}

void manage_frame(t_game *game)
{
    sfRectangleShape_setFillColor(game->menu.rectangle, sfTransparent);
    sfRectangleShape_setOutlineColor(game->menu.rectangle, sfWhite);
    sfRectangleShape_setOutlineThickness(game->menu.rectangle, 5);
    if ((game->mouse_p.x > 945 && game->mouse_p.x < 1075)
        && (game->mouse_p.y > 840 && game->mouse_p.y < 870)) {
        game->menu.Prectangle.x = 945;
        game->menu.Prectangle.y = 842;
        sfRectangleShape_setSize(game->menu.rectangle, (sfVector2f){130, 30});
    } else if ((game->mouse_p.x > 925 && game->mouse_p.x < 1095)
        && (game->mouse_p.y > 900 && game->mouse_p.y < 930)) {
        game->menu.Prectangle.x = 925;
        game->menu.Prectangle.y = 900;
        sfRectangleShape_setSize(game->menu.rectangle, (sfVector2f){170, 30});
    } else if ((game->mouse_p.x > 980 && game->mouse_p.x < 1035)
        && (game->mouse_p.y > 955 && game->mouse_p.y < 985)) {
        game->menu.Prectangle.x = 980;
        game->menu.Prectangle.y = 955;
        sfRectangleShape_setSize(game->menu.rectangle, (sfVector2f){60, 30});
    } sfRectangleShape_setPosition
        (game->menu.rectangle, game->menu.Prectangle);
}
