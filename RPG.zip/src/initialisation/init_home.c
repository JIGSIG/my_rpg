/*
** EPITECH PROJECT, 2019
** Function
** File description:
** Function
*/

#include "rpg.h"

void init_home(t_home *home)
{
    t_RECT rect;

    rect.width = 244;
    rect.heigth = 162;

    home->texture = sfTexture_createFromFile("assets/pause.png", NULL);
    home->sprite = sfSprite_create();
    sfSprite_setTexture(home->sprite, home->texture, sfTrue);
    home->view = sfView_create();
    home->clock = sfClock_create();
    set_rect(&home->rect, rect);
}
