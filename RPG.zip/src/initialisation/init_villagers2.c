/*
** EPITECH PROJECT, 2018
** rpg
** File description:
** include function
*/

#include "rpg.h"

void init_villager(t_villager **new)
{
    char **name = get_name(11, "villager_");
    int i = 0;

    if (!name)
        return;
    (*new) = create_node_villager(name[0]);
    while (name[++i]) {
        dlist_append_villager((*new), name[i]);
    }
}
