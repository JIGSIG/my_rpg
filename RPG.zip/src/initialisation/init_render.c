/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_render(t_render *new)
{
    new->mode.width = 1920;
    new->mode.height = 1080;
    new->mode.bitsPerPixel = 60;
    new->window = sfRenderWindow_create(new->mode, "RPG", RSZ | CLS, NULL);
    new->clock = sfClock_create();
}
