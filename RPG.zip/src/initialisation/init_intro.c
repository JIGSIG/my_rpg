/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_intro(t_intro *new)
{
    t_RECT rect = {0, 0, 1920, 1080};

    new->sprite = sfSprite_create();
    new->texture = sfTexture_createFromFile("assets/scene_1_to_4.jpg", NULL);
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    new->clock = sfClock_create();
    set_rect(&new->rect, rect);
}

void intro_anim(t_intro *intro, int offset, int max_value)
{
    intro->time = sfClock_getElapsedTime(intro->clock);
    intro->seconds = intro->time.microseconds / 100000;
    if (intro->seconds > 1.0) {
        intro->rect.left += offset;
        if (intro->rect.left == max_value) {
            intro->rect.left = 0;
        } sfClock_restart(intro->clock);
    }
}
