/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_particules(particule_t *new)
{
    t_RECT rect = {0, 0, 64, 64};

    new->clock = sfClock_create();
    new->ftime = 0;
    set_rect(&new->rect, rect);
}
