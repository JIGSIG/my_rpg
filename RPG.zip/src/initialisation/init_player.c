/*
** EPITECH PROJECT, 2018
** rpg
** File description:
** include function
*/

#include "rpg.h"

static t_stats get_stats_from_statfile(void)
{
    int fd = open(".player_info/stats_file", O_RDONLY);
    t_stats stat = {NULL, 0, 0, 0, 0, 0, 0};

    if (fd == -1)
        return (stat);
    stat.name = get_next_line(fd);
    stat.exp = my_getnbr(get_next_line(fd));
    stat.level = my_getnbr(get_next_line(fd));
    stat.attack = my_getnbr(get_next_line(fd));
    stat.defense = my_getnbr(get_next_line(fd));
    stat.health = my_getnbr(get_next_line(fd));
    stat.required = my_getnbr(get_next_line(fd));
    close(fd);
    return (stat);
}

void init_player(t_player *new)
{
    t_RECT rect = {0, 0, 32, 48};
    char **name = get_name(10, "pj_");
    t_pj *list = create_node(name[0]);
    t_stats new_stats = {"SIG", 0, 1, 10, 5, 30, 2};
    int i = 0;

    if (!name)
        return;
    while (name[++i]) {
        dlist_append(list, name[i]);
    } new->pj = list;
    new->clock = sfClock_create();
    new->position = (sfVector2f){1450, 2750};
    new->view = sfView_create();
    save_stats(&new_stats);
    new->stats = get_stats_from_statfile();
    set_rect(&new->rect, rect);
    new->map = player_move_blocks();
}

void display_level_up(t_game *game, bool *display)
{
    int x = game->player.position.x;
    int y = game->player.position.y;
    sfVector2f scale = {2, 2};

    sfSprite_setScale(game->level.sprite, (sfVector2f){1, 1});
    sfSprite_setPosition(game->level.sprite, (sfVector2f){x - 80, y - 120});
    if (game->status_IG == HOUSE) {
        sfSprite_setScale(game->level.sprite, scale);
        sfSprite_setPosition(game->level.sprite,
        (sfVector2f){x - 160, y - 240});
    } sfSprite_setTextureRect(game->level.sprite, game->level.rect);
    anim_level(192, 192 * 4, &game->level, display);
    sfRenderWindow_drawSprite
        (game->render.window, game->level.sprite, NULL);
}

void solo_leveling(t_stats *stat, t_game *game)
{
    static bool display = false;

    if (stat->exp >= stat->required) {
        stat->level++;
        stat->exp = 0;
        stat->attack += 5;
        stat->defense += 2;
        stat->health += 10;
        stat->required *= 2;
        display = true;
    } if (display == true) {
        display_level_up(game, &display);
    }
}
