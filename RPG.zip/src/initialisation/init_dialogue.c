/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_tchat(t_tchat *new)
{
    t_RECT coord = {0, 0, 520, 100};

    new->s_texture =
        sfTexture_createFromFile("assets/start_dialogue.png", NULL);
    new->s_sprite = sfSprite_create();
    new->clock = sfClock_create();
    sfSprite_setTexture(new->s_sprite, new->s_texture, sfTrue);
    set_rect(&new->s_rect, coord);
    new->c_texture =
        sfTexture_createFromFile("assets/chief_dialogue.png", NULL);
    new->c_sprite = sfSprite_create();
    sfSprite_setTexture(new->c_sprite, new->c_texture, sfTrue);
    set_rect(&new->c_rect, coord);
}

void tchat_anim(t_tchat *tchat, int offset, int max_value)
{
    tchat->time = sfClock_getElapsedTime(tchat->clock);
    tchat->seconds = tchat->time.microseconds / 100000;
    if (tchat->seconds > 10.0) {
        tchat->s_rect.top += offset;
        if (tchat->s_rect.top == max_value)
            tchat->s_rect.top = 0;
        sfClock_restart(tchat->clock);
    }
}
