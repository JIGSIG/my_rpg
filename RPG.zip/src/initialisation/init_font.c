/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_text(t_font *new)
{
    new->font = sfFont_createFromFile("font/Happy School.ttf");
    new->text = sfText_create();
    sfText_setFont(new->text, new->font);
}
