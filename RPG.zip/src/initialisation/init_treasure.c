/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

static void init_treasure2(t_treasure *new)
{
    t_RECT coord = {0, 0, 100, 97};

    new->explosion_texture =
        sfTexture_createFromFile("assets/explosion.png", NULL);
    new->explosion_sprite = sfSprite_create();
    new->explosion_clock = sfClock_create();
    sfSprite_setTexture(new->explosion_sprite, new->explosion_texture, sfTrue);
    set_rect(&new->explosion_rect, coord);
}

void init_treasure(t_treasure *new)
{
    t_RECT coord = {0, 0, 43, 89};

    new->texture = sfTexture_createFromFile("assets/treasure.png", NULL);
    new->sprite = sfSprite_create();
    new->clock = sfClock_create();
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
    set_rect(&new->rect, coord);
    init_treasure2(new);
}

static void explosion_anim
(t_treasure *treasure, int offset, int max_value, t_game *game)
{
    treasure->explosion_time =
        sfClock_getElapsedTime(treasure->explosion_clock);
    treasure->explosion_seconds =
        treasure->explosion_time.microseconds / 100000;
    if (treasure->explosion_seconds > 1.0) {
        treasure->explosion_rect.left += offset;
        if (treasure->explosion_rect.left == max_value) {
            treasure->explosion_rect.left = 0;
            treasure->explosion_rect.top += 97;
            if (treasure->explosion_rect.top == (97 * 3)) {
                treasure->explosion_rect.top = (97 * 3);
                game->status_IG = FIGHT;
            }
        } sfClock_restart(treasure->explosion_clock);
    }
}

static void display_explosion(t_treasure *treasure, t_game *game)
{
    int box_x = 920 - 30;
    int box_y = 270 - 50;

    if (game->status_IG != MAP)
        return;
    sfSprite_setPosition
        (treasure->explosion_sprite, (sfVector2f){box_x, box_y});
    sfSprite_setTextureRect
        (treasure->explosion_sprite, treasure->explosion_rect);
    explosion_anim(treasure, 100, 500, game);
    sfRenderWindow_drawSprite
        (game->render.window, treasure->explosion_sprite, NULL);
}

void treasure_anim
(t_treasure *treasure, int offset, int max_value, t_game *game)
{
    treasure->time = sfClock_getElapsedTime(treasure->clock);
    treasure->seconds = treasure->time.microseconds / 100000;
    if (treasure->seconds > 1.0) {
        treasure->rect.left += offset;
        if (treasure->rect.left == max_value) {
            treasure->rect.left = 2000;
        } sfClock_restart(treasure->clock);
    } if (treasure->rect.left >= 2000)
        display_explosion(treasure, game);
}
