/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void init_inventory(t_inventory *new)
{
    new->texture = sfTexture_createFromFile("assets/inventory.png", NULL);
    new->sprite = sfSprite_create();
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
}

void init_quit(t_quit *new)
{
    new->texture = sfTexture_createFromFile("assets/quit.jpg", NULL);
    new->sprite = sfSprite_create();
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
}

void init_configuration(t_config *new)
{
    new->texture = sfTexture_createFromFile("assets/config.png", NULL);
    new->sprite = sfSprite_create();
    sfSprite_setTexture(new->sprite, new->texture, sfTrue);
}
