/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"

void print_name2(t_game *game, char *name, sfVector2f position)
{
    sfText_setString(game->font.text, name);
    sfText_setPosition(game->font.text, position);
    sfText_setCharacterSize(game->font.text, 20);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void print_level2(t_game *game, char *level, sfVector2f position)
{
    sfText_setString(game->font.text, level);
    sfText_setPosition(game->font.text, position);
    sfText_setCharacterSize(game->font.text, 15);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void print_health2(t_game *game, char *health, sfVector2f position)
{
    sfText_setString(game->font.text, health);
    sfText_setPosition
        (game->font.text, (sfVector2f){position.x, position.y});
    sfText_setCharacterSize(game->font.text, 20);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
    print_bar(game, " / ", position);
    sfText_setString(game->font.text, health);
    sfText_setPosition
        (game->font.text, (sfVector2f){position.x + 50, position.y});
    sfText_setCharacterSize(game->font.text, 20);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void print_exp2
(t_game *game, char *exp, char *required, sfVector2f position)
{
    sfText_setString(game->font.text, exp);
    sfText_setPosition
        (game->font.text, (sfVector2f){position.x, position.y});
    sfText_setCharacterSize(game->font.text, 20);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
    print_bar(game, " / ", position);
    sfText_setString(game->font.text, required);
    sfText_setPosition
        (game->font.text, (sfVector2f){position.x + 50, position.y});
    sfText_setCharacterSize(game->font.text, 20);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}
