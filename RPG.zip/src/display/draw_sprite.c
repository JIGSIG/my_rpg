/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void draw_sprite(t_game *game, sfSprite *sprite)
{
    sfRenderWindow_drawSprite(game->render.window, sprite, NULL);
}

int set_position(p_img *img, int x, int y)
{
    img->pos.x = x;
    img->pos.y = y;
    sfSprite_setPosition(img->sprite, img->pos);
    return (0);
}

void display(t_game *game)
{
    sfRenderWindow_clear(game->render.window, sfBlack);
    menu_scene(game);
    selection_scene(game);
    intro_scene(game);
    game_scene(game);
    sfRenderWindow_display(game->render.window);
}
