/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

static void player_view_map(t_game *game)
{
    sfVector2u window_size = sfRenderWindow_getSize(game->render.window);
    sfVector2f size = {window_size.x / 2, window_size.y / 2};
    sfVector2f scale = {1, 1};

    sfSprite_setScale(game->player.pj->sprite, scale);
    sfView_setCenter(game->player.view, game->player.position);
    view_map_top(&game->player);
    view_map_bottom(&game->player);
    view_map_right(&game->player);
    view_map_left(&game->player);
    sfView_setSize(game->player.view, size);
    sfRenderWindow_setView(game->render.window, game->player.view);
}

static void player_view_house(t_game *game)
{
    sfVector2u window_size = sfRenderWindow_getSize(game->render.window);
    sfVector2f size = {window_size.x, window_size.y};
    sfVector2f scale = {2, 2};

    sfSprite_setScale(game->player.pj->sprite, scale);
    sfView_setCenter(game->player.view, game->player.position);
    view_house_top(&game->player);
    view_house_bottom(&game->player);
    view_house_right(&game->player);
    view_house_left(&game->player);
    sfView_setSize(game->player.view, size);
    sfRenderWindow_setView(game->render.window, game->player.view);
}

void view_manager(t_game *game, char *selection)
{
    if (selection == NULL)
        return;
    if (my_strcmp(selection, "player_m") == 0)
        player_view_map(game);
    if (my_strcmp(selection, "player_h") == 0)
        player_view_house(game);
}
