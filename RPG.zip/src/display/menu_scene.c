/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void display_menu(t_game *game, t_menu *menu)
{
    const sfView *dflt = sfRenderWindow_getDefaultView(game->render.window);

    sfRenderWindow_setView(game->render.window, dflt);
    manage_frame(game);
    sfRenderWindow_drawSprite(game->render.window, menu->sprite, NULL);
    sfRenderWindow_drawRectangleShape
        (game->render.window, game->menu.rectangle, NULL);
}

void menu_scene(t_game *game)
{
    start_menu_music(game);
    while (game->status_OG == MENU) {
        analyse_event(game, &game->render);
        sfRenderWindow_clear(game->render.window, sfBlack);
        manage_game_status(game);
        sfRenderWindow_display(game->render.window);
    }
}
