/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

static void display_choice(t_game *game, t_choice choice)
{
    sfVector2f scale = {0.65, 0.65};
    float x = choice.position.x;
    float y = choice.position.y;

    sfSprite_setScale(game->fight.sprite, scale);
    sfSprite_setPosition(game->fight.sprite, (sfVector2f){x, y});
    sfSprite_setTextureRect(game->fight.sprite, choice.rect);
    sfRenderWindow_drawSprite(game->render.window, game->fight.sprite, NULL);
}

static void display_fighter1(t_game *game, bool *turn)
{
    sfVector2u wsize = sfRenderWindow_getSize(game->render.window);
    sfVector2f scale = {7, 7};
    float x = 150;
    float y = wsize.y - (97 * scale.y);

    sfSprite_setScale(game->player.pj->sprite, scale);
    sfSprite_setPosition(game->player.pj->sprite, (sfVector2f){x, y});
    sfSprite_setTextureRect(game->player.pj->sprite, (sfIntRect){0, 0, 32, 30});
    sfRenderWindow_drawSprite
        (game->render.window, game->player.pj->sprite, NULL);
    game->choice.rect = (sfIntRect){CISOR, 0, 235, 320};
    game->choice.position = (sfVector2f){x + 200, 100};
    display_choice(game, game->choice);
    *turn = !(*turn);
}

static void display_fighter2(t_game *game, bool *turn)
{
    sfVector2u wsize = sfRenderWindow_getSize(game->render.window);
    sfVector2f scale = {7, 7};
    float x = wsize.x - 350;
    float y = 1080 - (97 * scale.y);

    sfSprite_setScale(game->villager->sprite, scale);
    sfSprite_setPosition(game->villager->sprite, (sfVector2f){x, y});
    sfSprite_setTextureRect(game->villager->sprite, (sfIntRect){0, 0, 32, 30});
    sfRenderWindow_drawSprite
        (game->render.window, game->villager->sprite, NULL);
    game->choice.rect = (sfIntRect){PIERRE, 0, 235, 320};
    game->choice.position = (sfVector2f){x - 200, 100};
    display_choice(game, game->choice);
    *turn = !(*turn);
}

void display_card(t_game *game)
{
    static bool turn = true;
    const sfView *dflt = sfRenderWindow_getDefaultView(game->render.window);
    sfVector2u wsize = sfRenderWindow_getSize(game->render.window);
    sfVector2f scale = {0.65, 0.65};
    float x = (wsize.x / 2) - ((723 * scale.x) / 2) + 25;
    float y = 1080 - (420 * scale.y);

    sfSprite_setScale(game->fight.sprite, scale);
    sfRenderWindow_setView(game->render.window, dflt);
    sfSprite_setPosition(game->fight.sprite, (sfVector2f){x, y});
    sfSprite_setTextureRect(game->fight.sprite, (sfIntRect){0, 0, 723, 320});
    sfRenderWindow_drawSprite
        (game->render.window, game->selection.sprite2, NULL);
    sfRenderWindow_drawSprite(game->render.window, game->fight.sprite, NULL);
    display_fighter1(game, &turn);
    display_fighter2(game, &turn);
    select_shifumi(game);
}
