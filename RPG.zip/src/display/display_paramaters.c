/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void display_inventory(t_game *game)
{
    const sfView *dflt = sfRenderWindow_getDefaultView(game->render.window);
    sfVector2f scale = {1.5, 1.5};
    int x = 900;
    int y = 25;

    sfSprite_setPosition(game->inventory.sprite, (sfVector2f){x, y});
    sfSprite_setScale(game->inventory.sprite, scale);
    sfRenderWindow_setView(game->render.window, dflt);
    sfRenderWindow_drawSprite
        (game->render.window, game->inventory.sprite, NULL);
}

void display_item(t_game *game)
{

    if (game->status_IG != ITEM)
        return;
    display_blur(game);
    display_inventory(game);
}

void display_configuration(t_game *game)
{
    const sfView *dflt = sfRenderWindow_getDefaultView(game->render.window);

    if (game->status_IG != CONFIGURATION)
        return;
    sfRenderWindow_setView(game->render.window, dflt);
    sfRenderWindow_drawSprite
        (game->render.window, game->config.sprite, NULL);
    display_volume(game);
}

void display_confirmation(t_game *game)
{
    const sfView *dflt = sfRenderWindow_getDefaultView(game->render.window);

    if (game->status_IG != CONFIRM)
        return;
    sfRenderWindow_setView(game->render.window, dflt);
    sfRenderWindow_drawSprite
        (game->render.window, game->quit.sprite, NULL);
}

void display_save(t_game *game)
{
    const sfView *dflt = sfRenderWindow_getDefaultView(game->render.window);

    if (game->status_IG != SAVE)
        return;
    sfRenderWindow_setView(game->render.window, dflt);
    display_blur(game);
    update_stats(&game->player);
}
