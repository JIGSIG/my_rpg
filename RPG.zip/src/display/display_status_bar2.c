/*
** EPITECH PROJECT, 2018
** framebuffer
** File description:
** include function
*/

#include "rpg.h"


static void display_status_map(t_game *game)
{
    float x = game->player.position.x - 500;
    float y = game->player.position.y - 250;

    sfSprite_setPosition(game->status_bar.sprite, (sfVector2f){x, y});
    sfRenderWindow_drawSprite
    (game->render.window, game->status_bar.sprite, NULL);
    print_name2(game, game->player.stats.name, (sfVector2f){x + 10, y - 10});
    print_level2(game, my_itoa(game->player.stats.level, 10),
    (sfVector2f){x + 70, y + 10});
    print_health2(game, my_itoa(game->player.stats.health, 10),
    (sfVector2f){x + 100, y + 30});
    print_exp2(game, my_itoa(game->player.stats.exp, 10),
    my_itoa(game->player.stats.required, 10),
    (sfVector2f){x + 100, y + 55});
    sfSprite_setPosition(game->player.pj->sprite, (sfVector2f){x + 25, y + 25});
    sfSprite_setTextureRect(game->player.pj->sprite, (sfIntRect){0, 0, 32, 48});
    sfRenderWindow_drawSprite
    (game->render.window, game->player.pj->sprite, NULL);
}

static void display_status_house(t_game *game)
{
    float x = 0;
    float y = game->player.position.y - 500;

    sfSprite_setPosition(game->status_bar.sprite, (sfVector2f){x, y});
    sfRenderWindow_drawSprite
    (game->render.window, game->status_bar.sprite, NULL);
    print_name2(game, game->player.stats.name, (sfVector2f){x + 10, y - 10});
    print_level2(game, my_itoa(game->player.stats.level, 10),
    (sfVector2f){x + 70, y + 10});
    print_health2(game, my_itoa(game->player.stats.health, 10),
    (sfVector2f){x + 100, y + 30});
    print_exp2(game, my_itoa(game->player.stats.exp, 10),
    my_itoa(game->player.stats.required, 10),
    (sfVector2f){x + 100, y + 55});
    sfSprite_setPosition(game->player.pj->sprite, (sfVector2f){x + 25, y + 25});
    sfSprite_setTextureRect(game->player.pj->sprite, (sfIntRect){0, 0, 32, 48});
    sfRenderWindow_drawSprite
    (game->render.window, game->player.pj->sprite, NULL);
}

void display_status_bar2(t_game *game)
{
    if (game->status_OG == INTRO)
        return;
    if (game->status_IG == MAP)
        display_status_map(game);
    if (game->status_IG == HOUSE)
        display_status_house(game);
}
