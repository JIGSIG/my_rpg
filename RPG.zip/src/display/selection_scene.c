/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void print_selection_name(t_game *game)
{
    sfText_setString(game->font.text, game->player.stats.name);
    sfText_setPosition(game->font.text, (sfVector2f){925, 865});
    sfText_setCharacterSize(game->font.text, 50);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void display_ring(t_game *game)
{
    sfVector2u w = sfRenderWindow_getSize(game->render.window);

    sfSprite_setPosition(game->selection.sprite,
    (sfVector2f){(w.x / 2) - 30, (w.y / 2) + 100});
    sfSprite_setTextureRect(game->selection.sprite, game->selection.rect);
    ring_anim(&game->selection, 64, 256);
    sfRenderWindow_drawSprite(game->render.window,
    game->selection.sprite, NULL);
}

void display_selection(t_game *game)
{
    const sfView *dflt = sfRenderWindow_getDefaultView(game->render.window);

    sfRenderWindow_setView(game->render.window, dflt);
    sfRenderWindow_drawSprite
    (game->render.window, game->selection.sprite2, NULL);
    display_ring(game);
    print_selection_name(game);
    if (game->player.pj->prev)
        display_prev(game);
    if (game->player.pj)
        display_current(game);
    if (game->player.pj->next)
        display_next(game);
}

void print_bar(t_game *game, char *str, sfVector2f pos)
{
    sfText_setString(game->font.text, str);
    sfText_setPosition(game->font.text, (sfVector2f){pos.x + 25, pos.y});
    sfText_setCharacterSize(game->font.text, 20);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void selection_scene(t_game *game)
{
    while (game->status_OG == SELECTION) {
        analyse_event(game, &game->render);
        sfRenderWindow_clear(game->render.window, sfBlack);
        display_selection(game);
        sfRenderWindow_display(game->render.window);
    }
}
