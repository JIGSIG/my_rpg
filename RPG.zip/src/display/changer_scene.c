/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

double **allocation_door(void)
{
    double **new = NULL;

    if (!(new = malloc(sizeof(double *) * 38)))
        return (NULL);
    for (int i = 0; i < 38; i++) {
        new[i] = NULL;
        if (!(new[i] = malloc(sizeof(double) * 4)))
            return (NULL);
    } new[38] = NULL;
    return (new);
}

bool in_front_of_door(t_player *player, sfVector2f *old_pos)
{
    double x;
    double y;
    double **door;

    x = player->position.x;
    y = player->position.y;
    door = all_doors();
    for (int i = 0; i < 38; i++) {
        if ((x >= door[i][0] && x <= door[i][1])
            && (y >= door[i][2] && y <= door[i][3])) {
            old_pos->x = x;
            old_pos->y = y;
            player->stats.exp += 1;
            return (true);
        }
    } return (false);
}

bool entrance(t_player *player, sfVector2f *old_pos)
{
    if (in_front_of_door(player, old_pos) == true) {
        player->position.x = 900;
        player->position.y = 980;
        return (true);
    } return (false);
}

bool departure(t_player *player, sfVector2f *old_pos)
{
    double x;
    double y;

    x = player->position.x;
    y = player->position.y;
    if ((x >= 835 && x <= 970) && (y >= 1000 && y <= 1010)) {
        player->position.x = old_pos->x;
        player->position.y = old_pos->y + 15;
        return (true);
    } return (false);
}

void change_scene(t_game *game)
{
    static sfVector2f old_pos = {0, 0};

    if (game->status_IG == MAP)
        if (sfKeyboard_isKeyPressed(sfKeyUp)
            && entrance(&game->player, &old_pos) == true)
        game->status_IG = HOUSE;
    if (game->status_IG == HOUSE)
        if (sfKeyboard_isKeyPressed(sfKeyDown)
            && departure(&game->player, &old_pos) == true)
        game->status_IG = MAP;
}
