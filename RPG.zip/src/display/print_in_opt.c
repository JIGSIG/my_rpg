/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void print_level(t_game *game, char *level)
{
    sfText_setString(game->font.text, level);
    sfText_setPosition(game->font.text, (sfVector2f){500, 75});
    sfText_setCharacterSize(game->font.text, 35);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void print_attack(t_game *game, char *attack)
{
    sfText_setString(game->font.text, attack);
    sfText_setPosition(game->font.text, (sfVector2f){500, 742});
    sfText_setCharacterSize(game->font.text, 25);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void print_defense(t_game *game, char *defense)
{
    sfText_setString(game->font.text, defense);
    sfText_setPosition(game->font.text, (sfVector2f){500, 800});
    sfText_setCharacterSize(game->font.text, 25);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void print_health(t_game *game, char *health)
{
    sfText_setString(game->font.text, health);
    sfText_setPosition(game->font.text, (sfVector2f){500, 692});
    sfText_setCharacterSize(game->font.text, 25);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
    print_bar(game, " / ", (sfVector2f){500, 692});
    sfText_setString(game->font.text, health);
    sfText_setPosition(game->font.text, (sfVector2f){500 + 50, 692});
    sfText_setCharacterSize(game->font.text, 25);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void print_required(t_game *game, char *required)
{
    print_bar(game, " / ", (sfVector2f){500, 845});
    sfText_setString(game->font.text, required);
    sfText_setPosition(game->font.text, (sfVector2f){500 + 50, 845});
    sfText_setCharacterSize(game->font.text, 25);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}
