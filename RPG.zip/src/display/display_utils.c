/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void display_person(t_game *game, t_person *person)
{
    int x = person->position1.x;
    int y = person->position1.y;

    if (game->status_OG == MENU || game->status_IG == OPTION)
        return;
    sfSprite_setPosition(person->sprite1, (sfVector2f){x, y});
    sfSprite_setTextureRect(person->sprite1, person->rect1);
    sfRenderWindow_drawSprite(game->render.window, person->sprite1, NULL);
}

void display_start_tchat(t_game *game)
{
    int p1x = game->person.position1.x;
    int p1y = game->person.position1.y;

    if (game->status_IG != MAP)
        return;
    if ((game->player.position.x >= p1x - 50
        && game->player.position.x <= p1x + 50)
        && ((game->player.position.y >= p1y - 50
        && game->player.position.y <= p1y + 50))) {
        sfSprite_setPosition
            (game->tchat.s_sprite, (sfVector2f){p1x, p1y - 100});
        sfSprite_setTextureRect(game->tchat.s_sprite, game->tchat.s_rect);
        tchat_anim(&game->tchat, 100, 300);
        sfRenderWindow_drawSprite
            (game->render.window, game->tchat.s_sprite, NULL);
    }
}

void display_chief_tchat(t_game *game)
{
    int chiefx = game->person.position2.x;
    int chiefy = game->person.position2.y;

    if (game->status_IG != MAP)
        return;
    if ((game->player.position.x >= chiefx - 50
        && game->player.position.x <= chiefx + 50)
        && ((game->player.position.y >= chiefy - 50
        && game->player.position.y <= chiefy + 50))) {
        sfSprite_setPosition
            (game->tchat.c_sprite, (sfVector2f){chiefx, chiefy - 100});
        sfSprite_setTextureRect(game->tchat.c_sprite, game->tchat.s_rect);
        tchat_anim(&game->tchat, 100, 300);
        sfRenderWindow_drawSprite
            (game->render.window, game->tchat.c_sprite, NULL);
    }
}

void display_treasure(t_game *game)
{
    int box_x = 920;
    int box_y = 270;

    if (game->status_IG != MAP)
        return;
    sfSprite_setPosition
        (game->treasure.sprite, (sfVector2f){box_x, box_y});
    sfSprite_setTextureRect(game->treasure.sprite, game->treasure.rect);
    if ((game->player.position.x >= box_x - 50
        && game->player.position.x <= box_x + 50)
        && ((game->player.position.y >= box_y - 50
        && game->player.position.y <= box_y + 50))) {
        treasure_anim(&game->treasure, 43, 344, game);
    } sfRenderWindow_drawSprite
        (game->render.window, game->treasure.sprite, NULL);
}

void display_person2(t_game *game, t_person *person)
{
    int x = person->position2.x;
    int y = person->position2.y;

    if (game->status_OG == MENU || game->status_IG == OPTION)
        return;
    sfSprite_setPosition(person->sprite2, (sfVector2f){x, y});
    sfSprite_setTextureRect(person->sprite2, person->rect2);
    sfRenderWindow_drawSprite(game->render.window, person->sprite2, NULL);
}
