/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

bool display_map_view(t_game *game)
{
    static float y = 0.3;
    static float check = 0.1;
    sfVector2f scale = {1, 1};

    sfSprite_setScale(game->player.pj->sprite, scale);
    sfRenderWindow_clear(game->render.window, sfBlack);
    display_map(game);
    sfView_move(game->player.view, (sfVector2f){0, y});
    sfView_setSize(game->player.view, (sfVector2f){(1920 / 1.3), (1080 / 1.3)});
    sfRenderWindow_setView(game->render.window, game->player.view);
    sfRenderWindow_display(game->render.window);
    check += 0.1;
    if (check >= (250 * (8 / 3)))
        return (false);
    return (true);
}

void after_story(t_game *game)
{
    bool value = true;

    if (game->intro.rect.left == 0) {
        sfView_setCenter(game->player.view, (sfVector2f){985, 600});
        value = display_map_view(game);
        while (value == true) {
            value = display_map_view(game);
        } sfView_setCenter(game->player.view, game->player.position);
        game->status_OG = GAME;
        game->status_IG = MAP;
    }
}

void display_intro(t_game *game)
{
    const sfView *dflt = sfRenderWindow_getDefaultView(game->render.window);
    sfVector2u w = sfRenderWindow_getSize(game->render.window);
    int i;

    sfRenderWindow_setView(game->render.window, dflt);
    sfSprite_setTextureRect(game->intro.sprite, game->intro.rect);
    intro_anim(&game->intro, 1920, 1920 * 4);
    sfText_setString(game->font.text, "PRESS ENTER TO SKIP");
    sfText_setPosition(game->font.text, (sfVector2f){w.x - 650, w.y - 150});
    sfText_setCharacterSize(game->font.text, 50);
    for (i = 0; i < 2250; i++) {
        sfRenderWindow_clear(game->render.window, sfBlack);
        analyse_event(game, &game->render);
        sfRenderWindow_drawSprite
            (game->render.window, game->intro.sprite, NULL);
        sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
        sfRenderWindow_display(game->render.window);
    } after_story(game);
}

void intro_scene(t_game *game)
{
    while (game->status_OG == INTRO) {
        analyse_event(game, &game->render);
        sfRenderWindow_clear(game->render.window, sfBlack);
        display_intro(game);
        sfRenderWindow_display(game->render.window);
    }
}
