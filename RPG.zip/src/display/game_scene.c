/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void display_character(t_game *game, t_player *player)
{
    int x = player->position.x;
    int y = player->position.y;
    int i;

    if (game->status_OG == MENU || game->status_IG == OPTION)
        return;
    sfSprite_setPosition(player->pj->sprite, (sfVector2f){x, y});
    sfSprite_setTextureRect(player->pj->sprite, player->rect);
    player_move(player, game->status_IG, game->status_OG);
    sfRenderWindow_drawSprite(game->render.window, player->pj->sprite, NULL);
    for (i = 0; i < 2; i++) {
        sfSprite_setPosition(game->rain.sprite, (sfVector2f){0, 0});
        sfSprite_setTextureRect(game->rain.sprite, game->rain.rect);
        anim_rain(&game->rain, 192, 1920);
        sfRenderWindow_drawSprite(game->render.window, game->rain.sprite, NULL);
    } solo_leveling(&player->stats, game);
}

void display_villagers(t_game *game, t_villager *villager)
{
    int x = villager->position.x;
    int y = villager->position.y;

    sfSprite_setPosition(villager->sprite, (sfVector2f){x, y});
    sfSprite_setTextureRect(villager->sprite, villager->rect);
    sfRenderWindow_drawSprite(game->render.window, villager->sprite, NULL);
}

void display_map(t_game *game)
{
    t_villager *tmp;

    tmp = game->villager;
    if (game->status_IG == MAP && game->status_OG == GAME)
        view_manager(game, "player_m");
    sfRenderWindow_drawSprite(game->render.window, game->map.sprite, NULL);
    display_treasure(game);
    display_character(game, &game->player);
    display_person(game, &game->person);
    display_person2(game, &game->person);
    while (game->villager->next) {
        move_villager(game->villager);
        display_villagers(game, game->villager);
        game->villager = game->villager->next;
    } game->villager = tmp;
    display_start_tchat(game);
    display_chief_tchat(game);
    game->old_status_IG = MAP;
    display_status_bar2(game);
}

void display_house(t_game *game)
{
    view_manager(game, "player_h");
    sfRenderWindow_drawSprite(game->render.window, game->house.sprite, NULL);
    display_status_bar2(game);
    display_character(game, &game->player);
    game->old_status_IG = HOUSE;
}

void game_scene(t_game *game)
{
    start_game_music(game);
    while (game->status_OG == GAME) {
        sfRenderWindow_clear(game->render.window, sfBlack);
        analyse_event(game, &game->render);
        change_scene(game);
        manage_game_status(game);
        sfRenderWindow_display(game->render.window);
    }
}
