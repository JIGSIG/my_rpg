/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

static char **convert_stats(t_stats *stat)
{
    char **new = NULL;

    new = malloc(sizeof(char *) * 8);
    if (!new)
        return (NULL);
    for (int i = 0; i < 8; i++) {
        new[i] = malloc(sizeof(char) * 256);
        if (!new[i])
            return (NULL);
    } new[0] = stat->name;
    new[1] = my_itoa(stat->exp, 10);
    new[2] = my_itoa((int)stat->level, 10);
    new[3] = my_itoa(stat->attack, 10);
    new[4] = my_itoa(stat->defense, 10);
    new[5] = my_itoa(stat->health, 10);
    new[6] = my_itoa(stat->required, 10);
    new[7] = NULL;
    return (new);
}

void print_name(t_game *game, char *name)
{
    sfText_setString(game->font.text, name);
    sfText_setPosition(game->font.text, (sfVector2f){365, 15});
    sfText_setCharacterSize(game->font.text, 50);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void print_exp(t_game *game, char *exp)
{
    sfText_setString(game->font.text, exp);
    sfText_setPosition(game->font.text, (sfVector2f){500, 845});
    sfText_setCharacterSize(game->font.text, 25);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}

void display_stat(t_game *game)
{
    char **stat = convert_stats(&game->player.stats);

    print_name(game, stat[0]);
    print_exp(game, stat[1]);
    print_level(game, stat[2]);
    print_attack(game, stat[3]);
    print_defense(game, stat[4]);
    print_health(game, stat[5]);
    print_required(game, stat[6]);
}

void display_option(t_game *game)
{
    const sfView *dflt = sfRenderWindow_getDefaultView(game->render.window);
    sfVector2f scale = {0.4, 0.4};

    sfSprite_setScale(game->finger.sprite, scale);
    sfRenderWindow_setView(game->render.window, dflt);
    set_finger_pos(&game->finger, game);
    selection2(&game->finger);
    sfRenderWindow_drawSprite
        (game->render.window, game->option.sprite, NULL);
    display_stat(game);
    sfSprite_setScale(game->player.pj->sprite, (sfVector2f){6, 6});
    sfSprite_setPosition(game->player.pj->sprite, (sfVector2f){475, 250});
    sfSprite_setTextureRect(game->player.pj->sprite, (sfIntRect){0, 0, 32, 48});
    sfRenderWindow_drawSprite
        (game->render.window, game->player.pj->sprite, NULL);
}
