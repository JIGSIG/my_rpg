/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void view_map_top(t_player *player)
{
    sfVector2f side;

    if (player->position.y <= 275) {
        side.x = player->position.x;
        side.y = 275;
        sfView_setCenter(player->view, side);
    }
}

void view_map_bottom(t_player *player)
{
    sfVector2f side;

    if (player->position.y >= 2825) {
        side.x = player->position.x;
        side.y = 2825;
        sfView_setCenter(player->view, side);
    }
}

void view_map_right(t_player *player)
{
    sfVector2f side;

    if (player->position.x >= 1435) {
        side.x = 1435;
        side.y = player->position.y;
        sfView_setCenter(player->view, side);
        if (player->position.y <= 275) {
            side.y = 275;
            sfView_setCenter(player->view, side);
        } if (player->position.y >= 2825) {
            side.y = 2825;
            sfView_setCenter(player->view, side);
        }
    }
}

void view_map_left(t_player *player)
{
    sfVector2f side;

    if (player->position.x <= 480) {
        side.x = 480;
        side.y = player->position.y;
        sfView_setCenter(player->view, side);
        if (player->position.y <= 275) {
            side.y = 275;
            sfView_setCenter(player->view, side);
        } if (player->position.y >= 2825) {
            side.y = 2825;
            sfView_setCenter(player->view, side);
        }
    }
}
