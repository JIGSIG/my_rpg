/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void display_prev(t_game *game)
{
    sfVector2u w = sfRenderWindow_getSize(game->render.window);

    sfSprite_setPosition(game->player.pj->prev->sprite,
    (sfVector2f){(w.x / 2) - 348, (w.y / 2) - 75});
    sfSprite_setTextureRect(game->player.pj->prev->sprite, game->player.rect);
    select_anim(&game->player, 32, 128, 0);
    sfSprite_setScale(game->player.pj->prev->sprite, (sfVector2f){3, 3});
    sfRenderWindow_drawSprite(game->render.window,
    game->player.pj->prev->sprite, NULL);
}

void display_current(t_game *game)
{
    sfVector2u w = sfRenderWindow_getSize(game->render.window);

    sfSprite_setPosition
        (game->player.pj->sprite, (sfVector2f){(w.x / 2) - 48, w.y / 2});
    sfSprite_setTextureRect(game->player.pj->sprite, game->player.rect);
    select_anim(&game->player, 32, 128, 96);
    sfSprite_setScale(game->player.pj->sprite, (sfVector2f){3, 3});
    sfRenderWindow_drawSprite(game->render.window,
    game->player.pj->sprite, NULL);
}

void display_next(t_game *game)
{
    sfVector2u w = sfRenderWindow_getSize(game->render.window);

    sfSprite_setPosition(game->player.pj->next->sprite,
    (sfVector2f){(w.x / 2) + 252, (w.y / 2) - 75});
    sfSprite_setTextureRect(game->player.pj->next->sprite, game->player.rect);
    if (game->player.pj->prev == NULL)
        select_anim(&game->player, 32, 128, 0);
    else
        select_anim(&game->player, 32, 128, 48);
    sfSprite_setScale(game->player.pj->next->sprite, (sfVector2f){3, 3});
    sfRenderWindow_drawSprite(game->render.window,
    game->player.pj->next->sprite, NULL);
}
