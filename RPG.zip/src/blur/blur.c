/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

static char *fill_fragshader(void)
{
    char *fragshader = " \
uniform sampler2D   source; \
uniform vec2        offsetFactor; \
\
void main() \
{ \
vec2 textureCoordinates = gl_TexCoord[0].xy; \
vec4 color = vec4(0.0); \
color += texture2D(source, textureCoordinates-4.0*offsetFactor)* 0.0162162162; \
color += texture2D(source, textureCoordinates-3.0*offsetFactor)* 0.0540540541; \
color += texture2D(source, textureCoordinates-2.0*offsetFactor)* 0.1216216216; \
color += texture2D(source, textureCoordinates-offsetFactor)* 0.1945945946; \
color += texture2D(source, textureCoordinates) * 0.2270270270; \
color += texture2D(source, textureCoordinates + offsetFactor) * 0.1945945946; \
color += texture2D(source, textureCoordinates+2.0*offsetFactor)*0.1216216216; \
color += texture2D(source, textureCoordinates+3.0*offsetFactor)* 0.0540540541; \
color += texture2D(source, textureCoordinates+4.0*offsetFactor)*0.0162162162; \
gl_FragColor = color; \
}";
    return (fragshader);
}

static void init_vertex(t_blur *new)
{
    sfVertex vert0 =
        {.position = (sfVector2f){0, 0}, .texCoords = (sfVector2f){0, 1}};
    sfVertex vert1 =
        {.position = (sfVector2f){1920, 0}, .texCoords = (sfVector2f){1, 1}};
    sfVertex vert2 =
        {.position = (sfVector2f){0, 1080}, .texCoords = (sfVector2f){0, 0}};
    sfVertex vert3 =
        {.position = (sfVector2f){1920, 1080}, .texCoords = (sfVector2f){1, 0}};

    new->vertices = sfVertexArray_create();
    sfVertexArray_append(new->vertices, vert0);
    sfVertexArray_append(new->vertices, vert1);
    sfVertexArray_append(new->vertices, vert2);
    sfVertexArray_append(new->vertices, vert3);
    sfVertexArray_setPrimitiveType(new->vertices, sfTrianglesStrip);
}

void init_blur(t_blur *new)
{
    new->area = (sfIntRect){0, 0, 1920, 1080};
    new->fragshader = fill_fragshader();
    init_vertex(new);
    new->shader = sfShader_createFromMemory(NULL, NULL, new->fragshader);
    new->states = (sfRenderStates){.shader = new->shader,
    .blendMode = sfBlendAlpha,
    .transform = sfTransform_Identity,
    .texture = NULL, };
    new->render_tex = sfRenderTexture_create(1920, 1080, sfFalse);
    new->texture = sfTexture_createFromFile("assets/option.png", &new->area);
    new->sprite = sfSprite_create();
    sfSprite_setScale(new->sprite, (sfVector2f){1.f, -1.f});
    sfSprite_setOrigin(new->sprite, (sfVector2f){0.f, 1080.f});
}

void display_blur(t_game *game)
{
    const sfTexture *tex1 = sfRenderTexture_getTexture(game->blur.render_tex);
    const sfTexture *tex2 = sfRenderTexture_getTexture(game->blur.render_tex);
    const sfView *dflt = sfRenderWindow_getDefaultView(game->render.window);

    sfRenderWindow_setView(game->render.window, dflt);
    sfShader_setTextureParameter
        (game->blur.shader, "source", game->blur.texture);
    sfShader_setVector2Parameter
        (game->blur.shader, "offsetFactor", (sfVector2f){0.f, 2.f/1080.f});
    sfRenderTexture_drawVertexArray
        (game->blur.render_tex, game->blur.vertices, &game->blur.states);
    sfRenderTexture_display(game->blur.render_tex);
    sfShader_setTextureParameter(game->blur.shader, "source", tex1);
    sfShader_setVector2Parameter
        (game->blur.shader, "offsetFactor", (sfVector2f){2.f/1920.f, 0.f});
    sfRenderTexture_drawVertexArray
        (game->blur.render_tex, game->blur.vertices, &game->blur.states);
    sfRenderTexture_display(game->blur.render_tex);
    sfSprite_setTexture(game->blur.sprite, tex2, sfTrue);
    sfRenderWindow_drawSprite(game->render.window, game->blur.sprite, NULL);
}
