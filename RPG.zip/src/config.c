/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void volume_up(t_game *game)
{
    sfListener_getGlobalVolume();
    game->volume += 1;
    if (game->volume > 100)
        game->volume = 100;
    sfListener_setGlobalVolume(game->volume);
}

void volume_down(t_game *game)
{
    sfListener_getGlobalVolume();
    game->volume -= 1;
    if (game->volume < 0)
        game->volume = 0;
    sfListener_setGlobalVolume(game->volume);
}

void active_volume(t_game *game)
{
    sfListener_setGlobalVolume(game->volume);
}

void mute_volume(void)
{
    sfListener_setGlobalVolume(0);
}

void display_volume(t_game *game)
{
    char *volume = my_itoa((int)game->volume, 10);

    if (game->status_IG != CONFIGURATION)
        return;
    sfText_setString(game->font.text, volume);
    sfText_setPosition(game->font.text, (sfVector2f){1515, 575});
    sfText_setCharacterSize(game->font.text, 100);
    sfRenderWindow_drawText(game->render.window, game->font.text, NULL);
}
