/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void set_rect(sfIntRect *rect, t_RECT coord)
{
    rect->left = coord.left;
    rect->top = coord.top;
    rect->width = coord.width;
    rect->height = coord.heigth;
}

void set_frect(sfFloatRect *rect, t_frect coord)
{
    rect->left = coord.left;
    rect->top = coord.top;
    rect->width = coord.width;
    rect->height = coord.heigth;
}

int game_engine(t_game *game)
{
    if (game->status_OG == EXIT)
        return (END);
    analyse_event(game, &game->render);
    game->render.time = sfClock_getElapsedTime(game->render.clock);
    game->render.seconds = sfTime_asSeconds(game->render.time);
    display(game);
    return (CONTINUE);
}
