/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

static void manage_status_1(t_game *game)
{
    switch (game->status_IG) {
    case MAP:
        display_map(game);
        break;
    case HOUSE:
        display_house(game);
        break;
    case OPTION:
        display_option(game);
        break;
    case FIGHT:
        display_card(game);
        break;
    }
}

static void manage_status_2(t_game *game)
{
    switch (game->status_IG) {
    case ITEM:
        display_item(game);
        break;
    case CONFIGURATION:
        display_configuration(game);
        break;
    case CONFIRM:
        display_confirmation(game);
        break;
    case SAVE:
        display_save(game);
        break;
    case RESUME:
        display_menu(game, &game->menu);
        break;
    }
}

void manage_game_status(t_game *game)
{
    manage_status_1(game);
    manage_status_2(game);
}
