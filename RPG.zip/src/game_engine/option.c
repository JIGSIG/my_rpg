/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void finger_anim(sfIntRect *rect, int offset, int max_value, t_finger *finger)
{
    finger->time = sfClock_getElapsedTime(finger->clock);
    finger->seconds = finger->time.microseconds / 100000;
    if (finger->seconds > 1.0) {
        rect->top += offset;
        if (rect->top == max_value)
            rect->top = 0;
        sfClock_restart(finger->clock);
    }
}

void set_finger_pos(t_finger *finger, t_game *game)
{
    int x = game->mouse_p.x;
    int y = game->mouse_p.y;

    if ((x > 300 && x < 900) && (y > 185 && y < 265)) {
        finger->position.x = 140;
        finger->position.y = 200;
    } else if ((x > 300 && x < 900) && (y > 310 && y < 390)) {
        finger->position.x = 140;
        finger->position.y = 340;
    } else if ((x > 300 && x < 900) && (y > 435 && y < 515)) {
        finger->position.x = 140;
        finger->position.y = 455;
    } else {
        finger->position.x = 950;
        finger->position.y = 500;
    }
}

void selection2(t_finger *finger)
{
    int x = finger->position.x;
    int y = finger->position.y;

    sfSprite_setPosition(finger->sprite, (sfVector2f){x, y});
    sfSprite_setTextureRect(finger->sprite, finger->rect);
    finger_anim(&finger->rect, 70, 210, finger);
}
