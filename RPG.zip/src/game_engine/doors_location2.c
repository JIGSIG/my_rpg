/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

double **fill_door_part5(void)
{
    double **door = fill_door_part4();
    int i = 18;

    door[++i][0] = 1785;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1335;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 700;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1620;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 1245;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1625;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 1435;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1560;
    door[i][3] = door[i][2] + 10;
    return (door);
}

double **fill_door_part6(void)
{
    double **door = fill_door_part5();
    int i = 22;

    door[++i][0] = 1565;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1655;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 1820;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1625;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 1115;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2040;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 640;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2005;
    door[i][3] = door[i][2] + 10;
    return (door);
}

double **fill_door_part7(void)
{
    double **door = fill_door_part6();
    int i = 26;

    door[++i][0] = 345;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2010;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 95;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2070;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 190;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2265;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 95;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2490;
    door[i][3] = door[i][2] + 10;
    return (door);
}

double **fill_door_part8(void)
{
    double **door = fill_door_part7();
    int i = 30;

    door[++i][0] = 350;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2390;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 575;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2330;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 895;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2200;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 765;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2390;
    door[i][3] = door[i][2] + 10;
    return (door);
}

double **all_doors(void)
{
    double **door = fill_door_part8();
    int i;

    i = 34;
    door[++i][0] = 990;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2390;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 350;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 2580;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 885;
    door[i][1] = 950;
    door[i][2] = 240;
    door[i][3] = 250;
    return (door);
}
