/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

double **door_entrance(void)
{
    double **door = allocation_door();

    if (!door)
        return (NULL);
    door[0][0] = 215;
    door[0][1] = 255;
    door[0][2] = 375;
    door[0][3] = 385;
    door[1][0] = 635;
    door[1][1] = 675;
    door[1][2] = 335;
    door[1][3] = 345;
    door[2][0] = 1245;
    door[2][1] = 1285;
    door[2][2] = 375;
    door[2][3] = 385;
    return (door);
}

double **fill_door_part1(void)
{
    double **door;

    door = door_entrance();
    door[3][0] = 215;
    door[3][1] = 255;
    door[3][2] = 535;
    door[3][3] = 545;
    door[4][0] = 125;
    door[4][1] = 165;
    door[4][2] = 725;
    door[4][3] = 735;
    door[5][0] = 535;
    door[5][1] = 575;
    door[5][2] = 500;
    door[5][3] = 510;
    door[6][0] = 505;
    door[6][1] = 545;
    door[6][2] = 660;
    door[6][3] = 670;
    return (door);
}

double **fill_door_part2(void)
{
    double **door = fill_door_part1();
    int i = 6;

    door[++i][0] = 1050;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 630;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 730;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 825;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 1275;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 760;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 250;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 890;
    door[i][3] = door[i][2] + 10;
    return (door);
}

double **fill_door_part3(void)
{
    double **door = fill_door_part2();
    int i = 10;

    door[++i][0] = 730;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1305;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 955;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1115;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 1050;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1080;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 1180;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1335;
    door[i][3] = door[i][2] + 10;
    return (door);
}

double **fill_door_part4(void)
{
    double **door = fill_door_part3();
    int i = 14;

    door[++i][0] = 1280;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1240;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 1530;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1210;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 1595;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1210;
    door[i][3] = door[i][2] + 10;
    door[++i][0] = 1820;
    door[i][1] = door[i][0] + 45;
    door[i][2] = 1115;
    door[i][3] = door[i][2] + 10;
    return (door);
}
