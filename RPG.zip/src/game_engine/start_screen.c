/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void anim_menu(int offset, int max_value, t_menu *menu)
{
    menu->time = sfClock_getElapsedTime(menu->clock);
    menu->seconds = menu->time.microseconds / 100000;
    if (menu->seconds > 2.5) {
        menu->rect.left += offset;
        menu->rect.left += 2;
        if (menu->rect.left == max_value) {
            menu->rect.top += 164;
            menu->rect.left = 0;
        } sfClock_restart(menu->clock);
    }
}
