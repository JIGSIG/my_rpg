/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

static void putstr_fd(int fd, char *str)
{
    int len;

    if (str == NULL)
        return;
    len = my_strlen(str);
    write(fd, str, len);
}

static void putnbr_fd(int fd, int nb)
{
    char c;

    if (nb < 0) {
        write(fd, "-", 1);
        nb = -nb;
    } if (nb >= 0 && nb < 10) {
        c = (nb + 48);
        write(fd, &c, 1);
    } else if (nb >= 10) {
        putnbr_fd(fd, nb / 10);
        putnbr_fd(fd, nb % 10);
    }
}

static int compare_stat(t_stats old, t_stats new)
{
    int vn;
    int ve;
    int vl;
    int va;
    int vd;
    int vh;
    int vs;

    if (old.name == NULL || new.name == NULL)
        return (1);
    vn = my_strcmp(old.name, new.name);
    ve = new.exp - old.exp;
    vl = new.level - old.level;
    va = new.attack - old.attack;
    vd = new.defense - old.defense;
    vh = new.health - old.health;
    vs = new.required - old.required;
    return ((vn + ve + vl + va + vd + vh + vs));
}

void save_stats(t_stats *stats)
{
    int fd = open(".player_info/stats_file", O_WRONLY | O_TRUNC);

    putstr_fd(fd, stats->name);
    write(fd, "\n", 1);
    putnbr_fd(fd, stats->exp);
    write(fd, "\n", 1);
    putnbr_fd(fd, stats->level);
    write(fd, "\n", 1);
    putnbr_fd(fd, stats->attack);
    write(fd, "\n", 1);
    putnbr_fd(fd, stats->defense);
    write(fd, "\n", 1);
    putnbr_fd(fd, stats->health);
    write(fd, "\n", 1);
    putnbr_fd(fd, stats->required);
    write(fd, "\n", 1);
    close(fd);
}

void update_stats(t_player *player)
{
    static t_stats old_stats = {"Sean", 0, 1, 10, 5, 30, 2};

    if (compare_stat(old_stats, player->stats) != 0) {
        old_stats = player->stats;
        save_stats(&player->stats);
    }
}
