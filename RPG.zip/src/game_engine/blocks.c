/*
** EPITECH PROJECT, 2019
** block
** File description:
** collisions manage function
*/

#include <string.h>
#include <stdio.h>
#include <stdlib.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>

#include "rpg.h"

char **player_move_blocks(void)
{
    int fd = open(".map", O_RDONLY);
    char *buff = malloc(sizeof(char) * 60000);
    char **blocks = malloc(sizeof(char *) * 308);

    if (fd == -1 || buff == NULL || blocks == NULL)
        return (NULL);
    read(fd, buff, 60000);
    for (int i = 0; i < 308; i++) {
        blocks[i] = malloc(sizeof(char) * 188);
        for (int n = 0; n < 188; n++) {
            blocks[i][n] = buff[(188 * (i + 1)) + n];
        } blocks[i][188] = '\0';
    } return (blocks);
}

bool check_player_move(t_player *player)
{
    int x = player->position.x / 10;
    int y = player->position.y / 10;
    if (player->map[y][x] == '#')
        return (false);
    return (true);
}
