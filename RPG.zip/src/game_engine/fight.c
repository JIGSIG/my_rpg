/*
** EPITECH PROJECT, 2019
** my_rpg
** File description:
** fight
*/

#include "rpg.h"

void manage_frame_fight(t_game *game)
{
    sfVector2u wsize = sfRenderWindow_getSize(game->render.window);
    float x = (wsize.x / 2) - ((723 * 0.65) / 2) + 25;
    float y = 1080 - (420 * 0.65);

    if ((game->mouse_p.x > x && game->mouse_p.x < ((x + 235) * 0.65))
        && (game->mouse_p.y > y && game->mouse_p.y < ((y + 320) * 0.65))) {
        game->fight.Prectangle.x = x;
        game->fight.Prectangle.y = y;
        sfRectangleShape_setSize(game->fight.rectangle, (sfVector2f){235, 320});
    } else if ((game->mouse_p.x > (x + 245) && game->mouse_p.x < (x + 480))
        && (game->mouse_p.y > y && game->mouse_p.y < y)) {
        game->fight.Prectangle.x = x + ((235 + 10) * 0.65);
        game->fight.Prectangle.y = y;
        sfRectangleShape_setSize(game->fight.rectangle, (sfVector2f){235, 320});
    } else if ((game->mouse_p.x > (x + 490) && game->mouse_p.x < (x + 725))
        && (game->mouse_p.y > y && game->mouse_p.y < y)) {
        game->fight.Prectangle.x = x + ((235 + 10 + 235) * 0.65);
        game->fight.Prectangle.y = y;
        sfRectangleShape_setSize(game->fight.rectangle, (sfVector2f){235, 320});
    } sfRectangleShape_setPosition
        (game->fight.rectangle, game->fight.Prectangle);
}

void select_shifumi(t_game *game)
{
    manage_frame_fight(game);
    sfRectangleShape_setFillColor(game->fight.rectangle, sfTransparent);
    sfRectangleShape_setOutlineColor(game->fight.rectangle, sfWhite);
    sfRectangleShape_setOutlineThickness(game->fight.rectangle, 5);
    sfRenderWindow_drawRectangleShape
        (game->render.window, game->fight.rectangle, NULL);
}
