/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void game_loop(t_game *game)
{
    while (sfRenderWindow_isOpen(game->render.window))
        if (game_engine(game) == END) {
            sfRenderWindow_close(game->render.window);
            break;
        }
}

void destroy_all(t_game *game)
{
    sfMusic_stop(game->map.music);
    sfMusic_destroy(game->map.music);
    sfMusic_destroy(game->menu.music);
}

int rpg_game(void)
{
    t_game game;

    init_game(&game);
    game_loop(&game);
    destroy_all(&game);
    return (SUCCESS);
}
