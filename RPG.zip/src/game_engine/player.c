/*
** EPITECH PROJECT, 2018
** my_rpg
** File description:
** include function
*/

#include "rpg.h"

void anim_player(int top, int offset, int max_value, t_player *player)
{
    player->time = sfClock_getElapsedTime(player->clock);
    player->seconds = player->time.microseconds / 100000;
    if (player->seconds > 1.0) {
        player->rect.top = top;
        player->rect.left += offset;
        if (player->rect.left == max_value) {
            player->rect.left = 0;
        } sfClock_restart(player->clock);
    }
}

void static_player(int top, t_player *player)
{
    player->time = sfClock_getElapsedTime(player->clock);
    player->seconds = player->time.microseconds / 100000;
    if (player->seconds > 1.0) {
        player->rect.top = top;
        player->rect.left = 0;
        sfClock_restart(player->clock);
    }
}

void player_move(t_player *player, int status_IG, int status_OG)
{
    static int direction = RIGHT;

    if (status_OG == INTRO)
        return;
    direction = move_up(player, &direction, status_IG);
    direction = move_down(player, &direction, status_IG);
    direction = move_left(player, &direction, status_IG);
    direction = move_right(player, &direction, status_IG);
    static_player(direction, player);
}
