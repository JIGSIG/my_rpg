/*
** EPITECH PROJECT, 2019
** my_strcat
** File description:
** create my_strcat
*/

#include "my.h"

char *my_strcat(char *src1, char *src2)
{
    char *cpy;
    int len1;
    int len2;
    int i;
    int j;

    len1 = my_strlen(src1);
    len2 = my_strlen(src2);
    cpy = malloc(sizeof(char) * (len1 + len2+ 1));
    for (i = 0; i < len1; i++)
        cpy[i] = src1[i];
    for (j = 0; j < len2; j++) {
        cpy[i] = src2[j];
        i++;
    } cpy[i] = 0;
    return (cpy);
}
