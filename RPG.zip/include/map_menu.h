/*
** EPITECH PROJECT, 2018
** map_menu
** File description:
** map_menu game
*/

#ifndef _MAP_MENU_H_
#define _MAP_MENU_H_

typedef struct s_menu
{
    sfTexture *texture;
    sfSprite *sprite;
    sfIntRect rect;
    sfClock *clock;
    sfTime time;
    float seconds;
    sfRectangleShape *rectangle;
    sfVector2f Prectangle;
    sfMusic *music;
} t_menu;

typedef struct s_home
{
    sfTexture *texture;
    sfSprite *sprite;
    sfIntRect rect;
    sfClock *clock;
    sfTime time;
    float seconds;
    sfView *view;
} t_home;

typedef struct s_map
{
    sfTexture *texture;
    sfSprite *sprite;
    sfMusic *music;
} t_map;

typedef struct s_house
{
    sfTexture *texture;
    sfSprite *sprite;
} t_house;

void init_menu(t_menu *);
void init_map(t_map *);
void init_house(t_house *);
void anim_menu(int offset, int max_value, t_menu *menu);

#endif
