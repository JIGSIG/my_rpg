/*
** EPITECH PROJECT, 2018
** treasure
** File description:
** treasure game
*/

#ifndef _TREASURE_H_
#define _TREASURE_H_

typedef struct s_treasure
{
    sfTexture *texture;
    sfSprite *sprite;
    sfIntRect rect;
    sfClock *clock;
    sfTime time;
    float seconds;
    sfTexture *explosion_texture;
    sfSprite *explosion_sprite;
    sfIntRect explosion_rect;
    sfClock *explosion_clock;
    sfTime explosion_time;
    float explosion_seconds;
} t_treasure;

void init_treasure(t_treasure *);

#endif
