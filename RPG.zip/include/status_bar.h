/*
** EPITECH PROJECT, 2018
** status_bar
** File description:
** game headers
*/

#ifndef _STATUS_BAR_H_
#define _STATUS_BAR_H_
#define _GNU_SOURCE

typedef struct t_status_bar t_status_bar;
struct t_status_bar
{
    sfSprite *sprite;
    sfTexture *texture;
};

void init_status_bar(t_status_bar *new);

#endif
