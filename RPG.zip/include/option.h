/*
** EPITECH PROJECT, 2018
** option
** File description:
** option game
*/

#ifndef _OPTION_H_
#define _OPTION_H_

typedef struct s_finger
{
    sfTexture *texture;
    sfSprite *sprite;
    sfVector2f position;
    sfIntRect rect;
    sfClock *clock;
    sfTime time;
    float seconds;
    sfVector2i mouse_p;
} t_finger;

typedef struct s_option
{
    sfTexture *texture;
    sfSprite *sprite;
} t_option;

void init_finger(t_finger *);
void init_option(t_option *);
void finger_anim(sfIntRect *rect, int offset, int max_value, t_finger *finger);
void selection2(t_finger *finger);

#endif
