/*
** EPITECH PROJECT, 2018
** blur
** File description:
** blur game
*/

#ifndef _BLUR_H_
#define _BLUR_H_

typedef struct t_blur t_blur;
struct t_blur
{
    char *fragshader;
    sfRenderWindow *window;
    sfVertexArray *vertices;
    sfRenderStates states;
    sfRenderTexture *render_tex;
    sfShader *shader;
    sfTexture *texture;
    sfSprite *sprite;
    sfIntRect area;
};

void init_blur(t_blur *new);

#endif
