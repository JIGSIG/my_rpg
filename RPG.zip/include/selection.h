/*
** EPITECH PROJECT, 2018
** selection
** File description:
** selection game
*/

#ifndef _SELECTION_H_
#define _SELECTION_H_

typedef struct t_selection t_selection;
struct t_selection
{
    sfSprite *sprite;
    sfTexture *texture;
    sfSprite *sprite2;
    sfTexture *texture2;
    sfVector2f position;
    sfIntRect rect;
    sfClock *clock;
    sfTime time;
    float seconds;
    float left;
    float top;
};

void select_anim(t_player *player, int offset, int max_value, int top);
void ring_anim(t_selection *, int offset, int max_value);
char **get_name(int nb_of_character, char *ID);

#endif
