/*
** EPITECH PROJECT, 2018
** player
** File description:
** player game
*/

#ifndef _PLAYER_H_
#define _PLAYER_H_

#define DOWN (0)
#define RIGHT (48)
#define LEFT (96)
#define UP (144)

typedef struct s_stats
{
    char *name;
    int exp;
    char level;
    int attack;
    int defense;
    int health;
    int required;
} t_stats;

typedef struct t_pj t_pj;
struct t_pj
{
    char *character;
    sfSprite *sprite;
    sfTexture *texture;
    t_pj *next;
    t_pj *prev;
};

typedef struct t_player t_player;
struct t_player
{
    t_pj *pj;
    sfClock *clock;
    sfTime time;
    float seconds;
    sfVector2f position;
    sfIntRect rect;
    sfView *view;
    t_stats stats;
    char **map;
};

void init_player(t_player *);
void anim_player(int top, int offset, int max_value, t_player *player);
void static_player(int top, t_player *player);
void player_move(t_player *player, int status_IG, int status_OG);
void view_map_top(t_player *player);
void view_map_bottom(t_player *player);
void view_map_right(t_player *player);
void view_map_left(t_player *player);
void view_house_top(t_player *player);
void view_house_bottom(t_player *player);
void view_house_right(t_player *player);
void view_house_left(t_player *player);
int move_down(t_player *player, int *old, int status_IG);
int move_left(t_player *player, int *old, int status_IG);
int move_right(t_player *player, int *old, int status_IG);
int move_up(t_player *player, int *old, int status_IG);
double **allocation_door(void);
double **door_entrance(void);
double **fill_door_part1(void);
double **fill_door_part2(void);
double **fill_door_part3(void);
double **fill_door_part4(void);
double **fill_door_part5(void);
double **fill_door_part6(void);
double **fill_door_part7(void);
double **fill_door_part8(void);
double **all_doors(void);
void save_stats(t_stats *stats);
void update_stats(t_player *player);
t_pj *dlist_append(t_pj *list, char *name);
t_pj *create_node(char *name);
char **player_move_blocks(void);
bool check_player_move(t_player *player);

#endif
