/*
** EPITECH PROJECT, 2018
** particules
** File description:
** game headers
*/

#ifndef _PARTICULES_H_
#define _PARTICULES_H_

typedef struct particule_s {
    sfTexture *texture;
    sfSprite *sprite;
    sfUint8 *pixels;
    sfIntRect rect;
    sfClock *clock;
    sfTime time;
    float seconds;
    float ftime;
}particule_t;

particule_t *new_particules(sfIntRect rect);
void update_particules(particule_t *particules);
void draw_particules(sfRenderWindow *window, particule_t *particules);

#endif
