/*
** EPITECH PROJECT, 2018
** rpg
** File description:
** game headers
*/

#ifndef _RPG_H_
#define _RPG_H_
#define _GNU_SOURCE
#define FPS (60)
#define SUCCESS (0)
#define FAILURE (84)
#define RSZ (sfResize)
#define CLS (sfClose)

//FIGHT
#define CISOR (0)
#define PIERRE (245)
#define FEUILLE (490)

//STATUS_IG
#define MAP (100)
#define HOUSE (102)
#define OPTION (103)
#define RESUME (101)
#define NEWGAME (99)
#define LOADGAME (98)
#define ITEM (90)
#define SAVE (96)
#define CONFIGURATION (95)
#define CONFIRM (94)
#define FIGHT (93)

//STATUS_OG
#define MENU (401)
#define SELECTION (402)
#define GAME (403)
#define INTRO (400)
#define CONTINUE (404)
#define END (405)
#define EXIT (406)

#include <SFML/Audio.h>
#include <SFML/Graphics.h>
#include <SFML/System.h>
#include <SFML/Window.h>
#include <math.h>
#include <stdlib.h>
#include <stdio.h>
#include <stdbool.h>
#include <string.h>
#include <unistd.h>
#include <sys/types.h>
#include <sys/stat.h>
#include <fcntl.h>
#include "map_menu.h"
#include "player.h"
#include "option.h"
#include "person.h"
#include "selection.h"
#include "get_next_line.h"
#include "villager.h"
#include "blur.h"
#include "level.h"
#include "inventory.h"
#include "font.h"
#include "intro.h"
#include "my.h"
#include "tchat.h"
#include "treasure.h"
#include "status_bar.h"
#include "fight.h"
#include "particules.h"

typedef struct s_RECT
{
    int left;
    int top;
    int width;
    int heigth;
} t_RECT;

typedef struct s_frect
{
    float left;
    float top;
    float width;
    float heigth;
} t_frect;

typedef struct s_render
{
    sfVideoMode mode;
    sfRenderWindow *window;
    sfEvent event;
    sfVector2u sizeMywindow;
    sfClock *clock;
    sfTime time;
    float seconds;
} t_render;

typedef struct t_rain t_rain;
struct t_rain
{
    sfSprite *sprite;
    sfTexture *texture;
    sfIntRect rect;
    sfClock *clock;
    sfTime time;
    float seconds;
};

typedef struct img
{
    sfTexture *texture;
    sfSprite *sprite;
    sfVector2f pos;
    sfVector2f relative_pos;
    sfIntRect rect;
} p_img;

typedef struct s_game
{
    t_render render;
    p_img i_part;
    t_menu menu;
    t_selection selection;
    t_house house;
    t_map map;
    t_home home;
    t_option option;
    t_finger finger;
    t_player player;
    t_villager *villager;
    t_inventory inventory;
    t_config config;
    t_quit quit;
    t_person person;
    t_rain rain;
    t_blur blur;
    t_font font;
    t_level level;
    t_intro intro;
    t_tchat tchat;
    t_treasure treasure;
    t_status_bar status_bar;
    t_fight fight;
    t_choice choice;
    particule_t particules;
    int status_OG;
    int status_IG;
    int old_status_IG;
    int old_status_OG;
    sfVector2i mouse_p;
    sfSound *sound;
    float volume;
} t_game;

////INIT
void init_render(t_render *);
void init_game(t_game *);

////GAME LOOP
//Events
void analyse_event(t_game *, t_render *);
void move_rectangle_up(t_game *);
void move_rectangle_down(t_game *);

//Engine
void set_rect(sfIntRect *, t_RECT);
int game_engine(t_game *);
int rpg_game(void);
//Draw
void display(t_game *);
void display_character(t_game *, t_player *);
void display_map(t_game *);
void display_house(t_game *);
void game_scene(t_game *);
void view_manager(t_game *, char *);
void display_option(t_game *);
void display_menu(t_game *, t_menu *);
void menu_scene(t_game *);
void check_event_option(sfMouseButtonEvent event, t_game *);
void check_event_game(sfMouseButtonEvent event, t_game *);
int my_strcmp(char const *, char const *);
void change_scene(t_game *);
void init_rain(t_rain *new);
void anim_rain(t_rain *rain, int offset, int max_value);
void check_event_menu(sfMouseButtonEvent event, t_game *);
void manage_frame(t_game *);
void start_game_music(t_game *);
void start_menu_music(t_game *);
void start_selection_music(t_game *);
void selection_scene(t_game *);
void init_selection(t_selection *new);
void check_event_selection(sfMouseButtonEvent event, t_game *);
void display_blur(t_game *);
void set_finger_pos(t_finger *finger, t_game *);
void manage_game_status(t_game *);
void display_blur(t_game *);
void display_item(t_game *);
void display_configuration(t_game *);
void display_confirmation(t_game *);
void check_event_confirm(sfMouseButtonEvent event, t_game *);
void display_stat(t_game *);
void solo_leveling(t_stats *stat, t_game *);
void volume_up(t_game *);
void volume_down(t_game *);
void active_volume(t_game *);
void mute_volume(void);
void display_volume(t_game *);
void check_event_config(t_game *);
char **story(void);
void display_intro(t_game *);
void intro_scene(t_game *);
void check_event_intro(sfMouseButtonEvent event, t_game *);
void set_frect(sfFloatRect *rect, t_frect coord);
void print_name(t_game *, char *name);
void print_exp(t_game *, char *exp);
void display_stat(t_game *);
void display_ring(t_game *);
void display_selection(t_game *);
void print_bar(t_game *, char *str, sfVector2f pos);
void selection_scene(t_game *);
void display_villagers(t_game *, t_villager *villager);
void display_character(t_game *, t_player *player);
void display_map(t_game *);
void display_house(t_game *);
void print_level(t_game *, char *level);
void print_attack(t_game *, char *attack);
void print_defense(t_game *, char *defense);
void print_health(t_game *, char *health);
void print_required(t_game *, char *required);
void display_person(t_game *, t_person *person);
void display_start_tchat(t_game *);
void display_chief_tchat(t_game *);
void display_treasure(t_game *);
void display_person2(t_game *, t_person *person);
void display_ring(t_game *);
void display_selection(t_game *);
void print_bar(t_game *, char *str, sfVector2f pos);
void display_prev(t_game *);
void display_current(t_game *);
void display_next(t_game *);
void display_inventory(t_game *);
void display_item(t_game *);
void display_configuration(t_game *);
void display_confirmation(t_game *);
void display_save(t_game *);
void display_status_bar2(t_game *game);
void print_name2(t_game *game, char *name, sfVector2f position);
void print_level2(t_game *game, char *level, sfVector2f position);
void print_health2(t_game *game, char *health, sfVector2f position);
void print_exp2(t_game *game, char *exp, char *required, sfVector2f position);
void treasure_anim(t_treasure *, int, int, t_game *);
void display_card(t_game *game);
void fight_scene(t_game *game);
void manage_frame_fight(t_game *game);
void select_shifumi(t_game *game);
void move_rectangle_right(t_game *game);
void move_rectangle_left(t_game *game);
void check_event_menu(sfMouseButtonEvent event, t_game *game);

#endif
