/*
** EPITECH PROJECT, 2018
** villager
** File description:
** game headers
*/

#ifndef _VILLAGER_H_
#define _VILLAGER_H_

typedef struct t_villager t_villager;
struct t_villager
{
    char *character;
    sfSprite *sprite;
    sfTexture *texture;
    sfClock *clock;
    sfTime time;
    float seconds;
    sfVector2f position;
    sfIntRect rect;
    sfView *view;
    t_stats stats;
    t_villager *next;
    t_villager *prev;
    size_t number;
};

t_villager *create_node_villager(char *name);
t_villager *dlist_append_villager(t_villager *list, char *name);
void init_villager(t_villager **new);
void anim_villager(int top, int offset, int max_value, t_villager *villager);
void move_villager_0(t_villager *villager);
void move_villager_1(t_villager *villager);
void move_villager_2(t_villager *villager);
void move_villager_3(t_villager *villager);
void move_villager_4(t_villager *villager);
void move_villager_5(t_villager *villager);
void move_villager_6(t_villager *villager);
void move_villager_7(t_villager *villager);
void move_villager_8(t_villager *villager);
void move_villager_9(t_villager *villager);
void move_villager_10(t_villager *villager);
void move_villager_11(t_villager *villager);
void move_villager(t_villager *villager);

#endif
