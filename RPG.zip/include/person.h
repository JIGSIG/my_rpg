/*
** EPITECH PROJECT, 2018
** player
** File description:
** player game
*/

#ifndef _PERSON_H_
#define _PERSON_H_

typedef struct t_person t_person;
struct t_person
{
    sfSprite *sprite1;
    sfTexture *texture1;
    sfVector2f position1;
    sfIntRect rect1;
    sfClock *clock1;
    sfTime time1;
    float seconds1;
    sfView *view1;
    t_stats stats1;
    t_person *next1;

    sfSprite *sprite2;
    sfTexture *texture2;
    sfVector2f position2;
    sfIntRect rect2;
    sfClock *clock2;
    sfTime time2;
    float seconds2;
    sfView *view2;
    t_stats stats2;
    t_person *next2;

    sfSprite *sprite3;
    sfTexture *texture3;
    sfVector2f position3;
    sfIntRect rect3;
    sfClock *clock3;
    sfTime time3;
    float seconds3;
    sfView *view3;
    t_stats stats3;
    t_person *next3;

    sfSprite *sprite4;
    sfTexture *texture4;
    sfVector2f position4;
    sfIntRect rect4;
    sfClock *clock4;
    sfTime time4;
    float seconds4;
    sfView *view4;
    t_stats stats4;
    t_person *next4;

    sfSprite *sprite5;
    sfTexture *texture5;
    sfVector2f position5;
    sfIntRect rect5;
    sfClock *clock5;
    sfTime time5;
    float seconds5;
    sfView *view5;
    t_stats stats5;
    t_person *next5;

    sfSprite *sprite6;
    sfTexture *texture6;
    sfVector2f position6;
    sfIntRect rect6;
    sfClock *clock6;
    sfTime time6;
    float seconds6;
    sfView *view6;
    t_stats stats6;
    t_person *next6;

    sfSprite *sprite7;
    sfTexture *texture7;
    sfVector2f position7;
    sfIntRect rect7;
    sfClock *clock7;
    sfTime time7;
    float seconds7;
    sfView *view7;
    t_stats stats7;
    t_person *next7;

    sfSprite *sprite8;
    sfTexture *texture8;
    sfVector2f position8;
    sfIntRect rect8;
    sfClock *clock8;
    sfTime time8;
    float seconds8;
    sfView *view8;
    t_stats stats8;
    t_person *next8;
};

void init_person(t_person *new);
void init_person2(t_person *new);

#endif
