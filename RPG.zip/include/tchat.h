/*
** EPITECH PROJECT, 2018
** tchat
** File description:
** tchat game
*/

#ifndef _TCHAT_H_
#define _TCHAT_H_

typedef struct s_tchat
{
    sfTexture *s_texture;
    sfSprite *s_sprite;
    sfIntRect s_rect;
    sfTexture *c_texture;
    sfSprite *c_sprite;
    sfIntRect c_rect;
    sfClock *clock;
    sfTime time;
    float seconds;
} t_tchat;

void init_tchat(t_tchat *);
void tchat_anim(t_tchat *tchat, int offset, int max_value);

#endif
