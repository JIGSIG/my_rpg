/*
** EPITECH PROJECT, 2018
** fight
** File description:
** game headers
*/

#ifndef _FIGHT_H_
#define _FIGHT_H_
#define _GNU_SOURCE

typedef struct t_choice t_choice;
struct t_choice
{
    sfIntRect rect;
    sfVector2f position;
};

typedef struct t_fight t_fight;
struct t_fight
{
    sfTexture *texture;
    sfSprite *sprite;
    sfIntRect rect;
    sfClock *clock;
    sfTime time;
    float seconds;
    sfRectangleShape *rectangle;
    sfVector2f Prectangle;
    sfMusic *music;
};

void init_fight(t_fight *new);

#endif
