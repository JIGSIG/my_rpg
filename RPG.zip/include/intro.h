/*
** EPITECH PROJECT, 2018
** intro
** File description:
** intro game
*/

#ifndef _INTRO_H_
#define _INTRO_H_

typedef struct t_intro t_intro;
struct t_intro
{
    char **text;
    sfSprite *sprite;
    sfTexture *texture;
    sfVector2f position;
    sfIntRect rect;
    sfClock *clock;
    sfTime time;
    float seconds;
    float left;
    float top;
};

void intro_anim(t_intro *, int offset, int max_value);
void init_intro(t_intro *new);

#endif
