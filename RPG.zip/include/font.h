/*
** EPITECH PROJECT, 2018
** font
** File description:
** game headers
*/

#ifndef _FONT_H_
#define _FONT_H_

typedef struct t_font t_font;
struct t_font
{
    sfFont *font;
    sfText *text;
};

void init_text(t_font *new);

#endif
