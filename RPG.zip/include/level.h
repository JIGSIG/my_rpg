/*
** EPITECH PROJECT, 2018
** level
** File description:
** game headers
*/

#ifndef _LEVEL_H_
#define _LEVEL_H_

typedef struct t_level t_level;
struct t_level
{
    sfSprite *sprite;
    sfTexture *texture;
    sfClock *clock;
    sfTime time;
    float seconds;
    sfVector2f position;
    sfIntRect rect;
};

void init_level(t_level *new);
void anim_level(int offset, int max_value,
                t_level *level, bool *display);

#endif
