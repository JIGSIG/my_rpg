/*
** EPITECH PROJECT, 2018
** inventory
** File description:
** inventory game
*/

#ifndef _INVENTORY_H_
#define _INVENTORY_H_

typedef struct t_inventory t_inventory;
struct t_inventory
{
    sfSprite *sprite;
    sfTexture *texture;
};

typedef struct t_config t_config;
struct t_config
{
    sfSprite *sprite;
    sfTexture *texture;
};

typedef struct t_quit t_quit;
struct t_quit
{
    sfSprite *sprite;
    sfTexture *texture;
};

void init_inventory(t_inventory *new);
void init_configuration(t_config *new);
void init_quit(t_quit *new);

#endif
